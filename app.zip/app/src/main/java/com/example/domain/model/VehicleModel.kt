package com.example.domain.model

import com.example.data.database.entities.Vehicle

data class VehicleModel(
    val id: Int = 0,
    val name: String,
    val type: String,
    val engine: String,
    val fuelType: String,
    val color: String,
    val icon: String,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toEntity(): Vehicle = Vehicle(
        id = id,
        name = name,
        type = type,
        engine = engine,
        fuelType = fuelType,
        color = color,
        icon = icon,
        isActive = isActive,
        createdAt = createdAt
    )

    companion object {
        fun fromEntity(entity: Vehicle): VehicleModel = VehicleModel(
            id = entity.id,
            name = entity.name,
            type = entity.type,
            engine = entity.engine,
            fuelType = entity.fuelType,
            color = entity.color,
            icon = entity.icon,
            isActive = entity.isActive,
            createdAt = entity.createdAt
        )
    }
}
