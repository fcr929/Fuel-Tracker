package com.example.domain.model

import com.example.data.database.entities.Refuel

data class RefuelModel(
    val id: Int = 0,
    val vehicleId: Int,
    val date: Long,
    val liters: Double,
    val isFull: Boolean,
    val priceTotal: Double,
    val pricePerLiter: Double,
    val odometer: Long,
    val location: String,
    val notes: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toEntity(): Refuel = Refuel(
        id = id,
        vehicleId = vehicleId,
        date = date,
        liters = liters,
        isFull = isFull,
        priceTotal = priceTotal,
        pricePerLiter = pricePerLiter,
        odometer = odometer,
        location = location,
        notes = notes,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    companion object {
        fun fromEntity(entity: Refuel): RefuelModel = RefuelModel(
            id = entity.id,
            vehicleId = entity.vehicleId,
            date = entity.date,
            liters = entity.liters,
            isFull = entity.isFull,
            priceTotal = entity.priceTotal,
            pricePerLiter = entity.pricePerLiter,
            odometer = entity.odometer,
            location = entity.location,
            notes = entity.notes,
            createdAt = entity.createdAt,
            updatedAt = entity.updatedAt
        )
    }
}
