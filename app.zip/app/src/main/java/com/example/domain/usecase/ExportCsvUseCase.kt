package com.example.domain.usecase

import android.content.Context
import android.net.Uri
import com.example.data.repository.RefuelRepository
import com.example.data.repository.VehicleRepository
import com.example.utils.CsvExporter
import kotlinx.coroutines.flow.first

class ExportCsvUseCase(
    private val vehicleRepository: VehicleRepository,
    private val refuelRepository: RefuelRepository,
    private val calculateConsumptionUseCase: CalculateConsumptionUseCase
) {
    suspend fun executeAll(context: Context): Uri? {
        val vehiclesList = vehicleRepository.allVehicles.first()
        val refuelsList = refuelRepository.allRefuels.first()
        
        val vehiclesMap = vehiclesList.associateBy { it.id }
        val refuelsAndVehicles = refuelsList.mapNotNull { refuel ->
            val vehicle = vehiclesMap[refuel.vehicleId]
            if (vehicle != null) refuel to vehicle else null
        }
        
        return CsvExporter.exportToCsvUri(
            context = context,
            refuelsAndVehicles = refuelsAndVehicles,
            calculateUseCase = calculateConsumptionUseCase,
            specificVehicleName = null
        )
    }

    suspend fun executeForVehicle(context: Context, vehicleId: Int): Uri? {
        val vehicle = vehicleRepository.getVehicleById(vehicleId) ?: return null
        val refuelsList = refuelRepository.getRefuelsForVehicle(vehicleId).first()
        
        val refuelsAndVehicles = refuelsList.map { it to vehicle }
        
        return CsvExporter.exportToCsvUri(
            context = context,
            refuelsAndVehicles = refuelsAndVehicles,
            calculateUseCase = calculateConsumptionUseCase,
            specificVehicleName = vehicle.name
        )
    }
}
