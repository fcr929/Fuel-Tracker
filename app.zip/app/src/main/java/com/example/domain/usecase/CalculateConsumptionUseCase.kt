package com.example.domain.usecase

import com.example.data.database.entities.Refuel

class CalculateConsumptionUseCase {
    /**
     * Calculates consumption in L/100km for a given refuel, relative to its previous chronological refuel.
     * Formula: (liters_repostaje_actual / km_entre_repostajes) * 100
     */
    fun execute(current: Refuel, previous: Refuel?): Double? {
        if (!current.isFull) return null
        if (previous == null) return null
        val kmDiff = current.odometer - previous.odometer
        if (kmDiff <= 0) return null
        return (current.liters / kmDiff) * 100.0
    }

    /**
     * Calculates consumptions for a list of refuels sorted in ascending chronological order.
     * Returns a list of Doubles? corresponding to each refuel in the same order.
     */
    fun calculateForList(refuelsAsc: List<Refuel>): List<Double?> {
        val result = mutableListOf<Double?>()
        for (i in refuelsAsc.indices) {
            val current = refuelsAsc[i]
            val previous = if (i > 0) refuelsAsc[i - 1] else null
            result.add(execute(current, previous))
        }
        return result
    }
}
