package com.example.domain.usecase

import com.example.data.database.entities.Refuel
import java.util.Calendar

data class VehicleStats(
    val lastRefuel: Refuel?,
    val averageConsumption: Double?, // in L/100km, null if not enough data
    val kmSinceLastRefuel: Long?,     // distance of the last refuel segment
    val averagePricePerLiter: Double?, // last 5 refuels
    val totalSpentThisMonth: Double
)

class GetStatsUseCase(private val calculateConsumptionUseCase: CalculateConsumptionUseCase) {

    fun execute(refuelsDescByDate: List<Refuel>): VehicleStats {
        if (refuelsDescByDate.isEmpty()) {
            return VehicleStats(
                lastRefuel = null,
                averageConsumption = null,
                kmSinceLastRefuel = null,
                averagePricePerLiter = null,
                totalSpentThisMonth = 0.0
            )
        }

        val lastRefuel = refuelsDescByDate.first()

        // 1. Refuels in ascending chronological order for consumption calculations
        val refuelsAsc = refuelsDescByDate.sortedBy { it.date }
        val consumptions = calculateConsumptionUseCase.calculateForList(refuelsAsc)
        
        // Average consumption of all valid calculated points
        val validConsumptions = consumptions.filterNotNull()
        val averageConsumption = if (validConsumptions.isNotEmpty()) {
            validConsumptions.average()
        } else {
            null
        }

        // 2. Km since last refuel: odometro(último) - odometro(penúltimo)
        // Since lastRefuel is index 0 in descending list, penúltimo is index 1.
        val kmSinceLastRefuel = if (refuelsDescByDate.size >= 2) {
            val penultimo = refuelsDescByDate[1]
            lastRefuel.odometer - penultimo.odometer
        } else {
            null
        }

        // 3. Average price (last 5 refuels)
        val last5 = refuelsDescByDate.take(5)
        val averagePricePerLiter = if (last5.isNotEmpty()) {
            last5.map { it.pricePerLiter }.average()
        } else {
            null
        }

        // 4. Total spent this month
        val currentCal = Calendar.getInstance()
        val currentYear = currentCal.get(Calendar.YEAR)
        val currentMonth = currentCal.get(Calendar.MONTH)
        
        val totalSpentThisMonth = refuelsDescByDate.filter { refuel ->
            val refuelCal = Calendar.getInstance().apply { timeInMillis = refuel.date }
            refuelCal.get(Calendar.YEAR) == currentYear && refuelCal.get(Calendar.MONTH) == currentMonth
        }.sumOf { it.priceTotal }

        return VehicleStats(
            lastRefuel = lastRefuel,
            averageConsumption = averageConsumption,
            kmSinceLastRefuel = kmSinceLastRefuel,
            averagePricePerLiter = averagePricePerLiter,
            totalSpentThisMonth = totalSpentThisMonth
        )
    }
}
