package com.example

import android.app.Application

class FuelTrackerApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        DependencyProvider.initialize(this)
    }
}
