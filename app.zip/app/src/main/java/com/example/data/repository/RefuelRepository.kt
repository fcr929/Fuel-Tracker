package com.example.data.repository

import com.example.data.database.dao.RefuelDao
import com.example.data.database.entities.Refuel
import kotlinx.coroutines.flow.Flow

class RefuelRepository(private val refuelDao: RefuelDao) {
    val allRefuels: Flow<List<Refuel>> = refuelDao.getAllRefuelsFlow()

    fun getRefuelsForVehicle(vehicleId: Int): Flow<List<Refuel>> {
        return refuelDao.getRefuelsForVehicleFlow(vehicleId)
    }

    suspend fun getRefuelsForVehicleAsc(vehicleId: Int): List<Refuel> {
        return refuelDao.getRefuelsForVehicleAsc(vehicleId)
    }

    suspend fun getRefuelById(id: Int): Refuel? = refuelDao.getRefuelById(id)

    fun getRefuelByIdFlow(id: Int): Flow<Refuel?> = refuelDao.getRefuelByIdFlow(id)

    suspend fun insert(refuel: Refuel): Long = refuelDao.insertRefuel(refuel)

    suspend fun update(refuel: Refuel) = refuelDao.updateRefuel(refuel)

    suspend fun delete(refuel: Refuel) = refuelDao.deleteRefuel(refuel)

    suspend fun deleteById(id: Int) = refuelDao.deleteRefuelById(id)

    suspend fun deleteForVehicle(vehicleId: Int) = refuelDao.deleteRefuelsForVehicle(vehicleId)
}
