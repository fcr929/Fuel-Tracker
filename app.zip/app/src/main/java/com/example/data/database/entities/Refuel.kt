package com.example.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "refuels",
    foreignKeys = [
        ForeignKey(
            entity = Vehicle::class,
            parentColumns = ["id"],
            childColumns = ["vehicleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["vehicleId"])]
)
data class Refuel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vehicleId: Int,
    val date: Long,                    // Timestamp Unix (fecha y hora del repostaje)
    val liters: Double,                // Litros repostados
    val isFull: Boolean,               // ¿Depósito lleno? true/false
    val priceTotal: Double,            // Precio total pagado (€)
    val pricePerLiter: Double,         // Precio por litro (€/L) — calculado o introducido
    val odometer: Long,                // Km totales del odómetro
    val location: String,              // Lugar/gasolinera (texto libre)
    val notes: String,                 // Anotación libre opcional
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
