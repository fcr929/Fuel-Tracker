package com.example.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "fuel_tracker_settings")

enum class AppTheme {
    SYSTEM, LIGHT, DARK
}

class ThemePreferenceManager(private val context: Context) {
    companion object {
        val THEME_KEY = stringPreferencesKey("theme_preference")
    }

    val themePreference: Flow<AppTheme> = context.dataStore.data.map { preferences ->
        val themeStr = preferences[THEME_KEY] ?: AppTheme.SYSTEM.name
        try {
            AppTheme.valueOf(themeStr)
        } catch (e: Exception) {
            AppTheme.SYSTEM
        }
    }

    suspend fun setThemePreference(theme: AppTheme) {
        context.dataStore.edit { preferences ->
            preferences[THEME_KEY] = theme.name
        }
    }
}
