package com.example.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "fuel_tracker_settings")

enum class AppTheme {
    SYSTEM, LIGHT, DARK
}

data class UserUnits(
    val currencySymbol: String = "€",
    val currencyName: String = "Euro",
    val currencyFlag: String = "🇪🇺",
    val distanceUnit: String = "km",
    val volumeUnit: String = "L"
) {
    val consumptionUnit: String
        get() = when {
            distanceUnit == "km" && volumeUnit == "L" -> "L/100km"
            distanceUnit == "mi" && volumeUnit == "gal_us" -> "mpg (US)"
            distanceUnit == "mi" && volumeUnit == "gal_uk" -> "mpg (UK)"
            distanceUnit == "km" && volumeUnit == "gal_us" -> "km/gal"
            distanceUnit == "km" && volumeUnit == "gal_uk" -> "km/gal (UK)"
            else -> "L/100km"
        }
}

class ThemePreferenceManager(private val context: Context) {
    companion object {
        val THEME_KEY = stringPreferencesKey("theme_preference")
        val CURRENCY_SYMBOL = stringPreferencesKey("currency_symbol")
        val CURRENCY_NAME = stringPreferencesKey("currency_name")
        val CURRENCY_FLAG = stringPreferencesKey("currency_flag")
        val DISTANCE_UNIT = stringPreferencesKey("distance_unit")
        val VOLUME_UNIT = stringPreferencesKey("volume_unit")
    }

    val themePreference: Flow<AppTheme> = context.dataStore.data.map { preferences ->
        val themeStr = preferences[THEME_KEY] ?: AppTheme.SYSTEM.name
        try {
            AppTheme.valueOf(themeStr)
        } catch (e: Exception) {
            AppTheme.SYSTEM
        }
    }

    val userUnits: Flow<UserUnits> = context.dataStore.data.map { preferences ->
        UserUnits(
            currencySymbol = preferences[CURRENCY_SYMBOL] ?: "€",
            currencyName = preferences[CURRENCY_NAME] ?: "Euro",
            currencyFlag = preferences[CURRENCY_FLAG] ?: "🇪🇺",
            distanceUnit = preferences[DISTANCE_UNIT] ?: "km",
            volumeUnit = preferences[VOLUME_UNIT] ?: "L"
        )
    }

    suspend fun setThemePreference(theme: AppTheme) {
        context.dataStore.edit { preferences ->
            preferences[THEME_KEY] = theme.name
        }
    }

    suspend fun setCurrency(symbol: String, name: String, flag: String) {
        context.dataStore.edit { preferences ->
            preferences[CURRENCY_SYMBOL] = symbol
            preferences[CURRENCY_NAME] = name
            preferences[CURRENCY_FLAG] = flag
        }
    }

    suspend fun setDistanceUnit(unit: String) {
        context.dataStore.edit { preferences ->
            preferences[DISTANCE_UNIT] = unit
        }
    }

    suspend fun setVolumeUnit(unit: String) {
        context.dataStore.edit { preferences ->
            preferences[VOLUME_UNIT] = unit
        }
    }
}
