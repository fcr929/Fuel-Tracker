package com.example.data.repository

import com.example.data.database.dao.VehicleDao
import com.example.data.database.entities.Vehicle
import kotlinx.coroutines.flow.Flow

class VehicleRepository(private val vehicleDao: VehicleDao) {
    val allVehicles: Flow<List<Vehicle>> = vehicleDao.getAllVehiclesFlow()
    val activeVehicles: Flow<List<Vehicle>> = vehicleDao.getActiveVehiclesFlow()

    suspend fun getAllVehiclesList(): List<Vehicle> = vehicleDao.getAllVehicles()

    suspend fun getVehicleById(id: Int): Vehicle? = vehicleDao.getVehicleById(id)

    fun getVehicleByIdFlow(id: Int): Flow<Vehicle?> = vehicleDao.getVehicleByIdFlow(id)

    suspend fun insert(vehicle: Vehicle): Long = vehicleDao.insertVehicle(vehicle)

    suspend fun update(vehicle: Vehicle) = vehicleDao.updateVehicle(vehicle)

    suspend fun delete(vehicle: Vehicle) = vehicleDao.deleteVehicle(vehicle)
}
