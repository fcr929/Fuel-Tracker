package com.example.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,                  // Nombre del vehículo (ej: "Coche", "PCX")
    val type: String,                  // Tipo: "Coche", "Moto", "Furgoneta", "Camión", etc.
    val engine: String,                // Motor/cilindrada (ej: "1.6 TDI", "125cc")
    val fuelType: String,              // Combustible: "Gasolina 95", "Gasolina 98", "Diésel", "GLP", "Eléctrico", "Híbrido"
    val color: String,                 // Color HEX para identificar el vehículo visualmente en la UI
    val icon: String,                  // Identificador de icono (ej: "ic_car", "ic_motorcycle", "ic_van")
    val isActive: Boolean = true,      // Para ocultar vehículos sin borrar historial
    val createdAt: Long = System.currentTimeMillis() // Timestamp de creación
)
