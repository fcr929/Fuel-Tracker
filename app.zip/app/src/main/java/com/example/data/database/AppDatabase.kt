package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.database.dao.RefuelDao
import com.example.data.database.dao.VehicleDao
import com.example.data.database.entities.Refuel
import com.example.data.database.entities.Vehicle

@Database(entities = [Vehicle::class, Refuel::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun refuelDao(): RefuelDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fuel_tracker_database"
                )
                .fallbackToDestructiveMigration() // Simple for demo & internal storage
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
