package com.example.data.database.dao

import androidx.room.*
import com.example.data.database.entities.Refuel
import kotlinx.coroutines.flow.Flow

@Dao
interface RefuelDao {
    @Query("SELECT * FROM refuels ORDER BY date DESC, createdAt DESC")
    fun getAllRefuelsFlow(): Flow<List<Refuel>>

    @Query("SELECT * FROM refuels WHERE vehicleId = :vehicleId ORDER BY date DESC, odometer DESC")
    fun getRefuelsForVehicleFlow(vehicleId: Int): Flow<List<Refuel>>

    @Query("SELECT * FROM refuels WHERE vehicleId = :vehicleId ORDER BY date ASC, odometer ASC")
    suspend fun getRefuelsForVehicleAsc(vehicleId: Int): List<Refuel>

    @Query("SELECT * FROM refuels WHERE id = :id")
    suspend fun getRefuelById(id: Int): Refuel?

    @Query("SELECT * FROM refuels WHERE id = :id")
    fun getRefuelByIdFlow(id: Int): Flow<Refuel?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRefuel(refuel: Refuel): Long

    @Update
    suspend fun updateRefuel(refuel: Refuel)

    @Delete
    suspend fun deleteRefuel(refuel: Refuel)

    @Query("DELETE FROM refuels WHERE id = :id")
    suspend fun deleteRefuelById(id: Int)
}
