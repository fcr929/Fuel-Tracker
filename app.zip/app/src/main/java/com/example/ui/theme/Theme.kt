package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ProfessionalDarkTealPrimary,
    onPrimary = ProfessionalDarkTealOnPrimary,
    primaryContainer = ProfessionalDarkAccentPurpleBg,
    onPrimaryContainer = ProfessionalDarkAccentPurpleText,
    secondary = ProfessionalDarkTealPrimary,
    onSecondary = ProfessionalDarkTealOnPrimary,
    background = ProfessionalDarkBg,
    onBackground = Color(0xFFE2E8F0),
    surface = ProfessionalDarkSurface,
    onSurface = Color(0xFFE2E8F0),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF334155),
    outlineVariant = Color(0xFF475569)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = ProfessionalTealPrimary,
    onPrimary = ProfessionalTealOnPrimary,
    primaryContainer = ProfessionalAccentPurpleBg,
    onPrimaryContainer = ProfessionalAccentPurpleText,
    secondary = Color(0xFF006A6A),
    onSecondary = Color.White,
    background = ProfessionalWarmBg,
    onBackground = ProfessionalTextDark,
    surface = ProfessionalSurfaceWhite,
    onSurface = ProfessionalTextDark,
    surfaceVariant = Color(0xFFF1ECE9),
    onSurfaceVariant = ProfessionalTextMedium,
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFFE2E8F0)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
