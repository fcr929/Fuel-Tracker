package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.utils.VehicleVisuals

@Composable
fun VehicleChip(
    name: String,
    colorHex: String,
    iconName: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vehicleColor = VehicleVisuals.parseColor(colorHex, MaterialTheme.colorScheme.primary)
    val iconVector = VehicleVisuals.getIconVector(iconName)

    val containerColor = if (isSelected) {
        vehicleColor
    } else {
        MaterialTheme.colorScheme.surface
    }

    val borderColor = if (isSelected) {
        Color.Transparent
    } else {
        MaterialTheme.colorScheme.outlineVariant
    }

    val iconColor = if (isSelected) {
        Color.White
    } else {
        vehicleColor
    }

    val textColor = if (isSelected) {
        Color.White
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Row(
        modifier = modifier
            .testTag("vehicle_chip_${name.lowercase().replace(" ", "_")}")
            .clip(CircleShape)
            .background(containerColor)
            .border(
                width = 1.dp,
                color = if (isSelected) Color.Transparent else borderColor,
                shape = CircleShape
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        // Colored indicator circle as in HTML
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (isSelected) Color.White else vehicleColor)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Icon(
            imageVector = iconVector,
            contentDescription = null,
            tint = iconColor,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Medium
            ),
            color = textColor
        )
    }
}
