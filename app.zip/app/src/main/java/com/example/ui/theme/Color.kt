package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Light Palette
val ProfessionalTealPrimary = Color(0xFF006A6A)
val ProfessionalTealOnPrimary = Color(0xFFFFFFFF)
val ProfessionalWarmBg = Color(0xFFFDF8F6)
val ProfessionalSurfaceWhite = Color(0xFFFFFFFF)

val ProfessionalTextDark = Color(0xFF1E293B)
val ProfessionalTextMedium = Color(0xFF475569)
val ProfessionalTextLight = Color(0xFF94A3B8)

// Accent definitions from Design HTML
val ProfessionalAccentPurpleBg = Color(0xFFE8DEF8)
val ProfessionalAccentPurpleText = Color(0xFF1D192B)

val ProfessionalCoolGrayGreen = Color(0xFFF3F4F1)
val ProfessionalIceBlueBg = Color(0xFFECF3FF)
val ProfessionalIceBlueText = Color(0xFF104F55) // Custom dark teal matching deep blue-green of Design HTML

// Insight elements
val ProfessionalInsightBg = Color(0xFFFFF7E6)
val ProfessionalInsightBorder = Color(0xFFFFE099)
val ProfessionalInsightText = Color(0xFF664D03)

// Dark version equivalent palette for seamless dark support
val ProfessionalDarkBg = Color(0xFF0F172A)
val ProfessionalDarkSurface = Color(0xFF1E293B)
val ProfessionalDarkTealPrimary = Color(0xFF4DB6AC)
val ProfessionalDarkTealOnPrimary = Color(0xFF003737)
val ProfessionalDarkAccentPurpleBg = Color(0xFF4F378B)
val ProfessionalDarkAccentPurpleText = Color(0xFFE8DEF8)
