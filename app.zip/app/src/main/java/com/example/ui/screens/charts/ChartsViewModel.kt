package com.example.ui.screens.charts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.DependencyProvider
import com.example.data.database.entities.Refuel
import com.example.data.database.entities.Vehicle
import com.example.data.repository.RefuelRepository
import com.example.data.repository.VehicleRepository
import com.example.domain.usecase.CalculateConsumptionUseCase
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

enum class ChartPeriod(val label: String) {
    THREE_MONTHS("3 Meses"),
    SIX_MONTHS("6 Meses"),
    ONE_YEAR("1 Año"),
    ALL("Todo")
}

data class ConsumptionPoint(
    val date: Long,
    val value: Double,
    val kmTraveled: Long
)

data class DistancePoint(
    val date: Long,
    val value: Long,
    val isFull: Boolean,
    val isHigherThanAvg: Boolean?, // true: higher (red), false: lower (green), null: partial/no comparative
    val consumptionVal: Double?
)

data class PricePoint(
    val date: Long,
    val value: Double,
    val location: String
)

@OptIn(ExperimentalCoroutinesApi::class)
class ChartsViewModel(
    private val themePreferenceManager: com.example.data.datastore.ThemePreferenceManager = DependencyProvider.themePreferenceManager,
    private val vehicleRepository: VehicleRepository = DependencyProvider.vehicleRepository,
    private val refuelRepository: RefuelRepository = DependencyProvider.refuelRepository,
    private val calculateConsumptionUseCase: CalculateConsumptionUseCase = DependencyProvider.calculateConsumptionUseCase
) : ViewModel() {

    val userUnits: StateFlow<com.example.data.datastore.UserUnits> = themePreferenceManager.userUnits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), com.example.data.datastore.UserUnits())

    val activeVehicles: StateFlow<List<Vehicle>> = vehicleRepository.activeVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedVehicleId = MutableStateFlow<Int?>(null)
    val selectedVehicleId: StateFlow<Int?> = _selectedVehicleId.asStateFlow()

    private val _selectedPeriod = MutableStateFlow(ChartPeriod.SIX_MONTHS)
    val selectedPeriod: StateFlow<ChartPeriod> = _selectedPeriod.asStateFlow()

    init {
        viewModelScope.launch {
            activeVehicles.collect { vehicles ->
                if (_selectedVehicleId.value == null && vehicles.isNotEmpty()) {
                    _selectedVehicleId.value = vehicles.first().id
                }
            }
        }
    }

    fun selectVehicle(vehicleId: Int) {
        _selectedVehicleId.value = vehicleId
    }

    fun selectPeriod(period: ChartPeriod) {
        _selectedPeriod.value = period
    }

    // Raw refuels for the selected vehicle sorted chronological (ascending)
    val selectedVehicleRefuels: StateFlow<List<Refuel>> = _selectedVehicleId
        .flatMapLatest { id ->
            if (id != null) {
                refuelRepository.getRefuelsForVehicle(id).map { list -> list.sortedBy { it.date } }
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Computes all metrics over the entire history so stats/averages are accurate,
    // then crops to the selected period.
    val chartData: StateFlow<ChartData> = combine(
        selectedVehicleRefuels,
        _selectedPeriod
    ) { refuelsAsc, period ->
        if (refuelsAsc.isEmpty()) {
            return@combine ChartData()
        }

        val cutoffTime = getCutoffTimestamp(period)

        // Calculate chronological consumptions and distances
        val consumptions = calculateConsumptionUseCase.calculateForList(refuelsAsc)
        val validConsumptions = consumptions.filterNotNull()
        val globalAvgConsumption = if (validConsumptions.isNotEmpty()) validConsumptions.average() else 0.0

        val consumptionPoints = mutableListOf<ConsumptionPoint>()
        val distancePoints = mutableListOf<DistancePoint>()
        val pricePoints = mutableListOf<PricePoint>()

        for (i in refuelsAsc.indices) {
            val current = refuelsAsc[i]
            val prev = if (i > 0) refuelsAsc[i - 1] else null
            
            // Skip points before cutoff for chart visuals
            val isIncluded = current.date >= cutoffTime

            // Consumption point
            val cons = consumptions[i]
            if (cons != null && isIncluded) {
                val km = if (prev != null) current.odometer - prev.odometer else 0L
                consumptionPoints.add(ConsumptionPoint(current.date, cons, km))
            }

            // Distance point
            if (isIncluded) {
                val km = if (prev != null) current.odometer - prev.odometer else 0L
                val isHigher = if (cons != null && globalAvgConsumption > 0) {
                    cons > globalAvgConsumption
                } else null
                distancePoints.add(DistancePoint(current.date, km, current.isFull, isHigher, cons))
            }

            // Price point
            if (isIncluded) {
                pricePoints.add(PricePoint(current.date, current.pricePerLiter, current.location))
            }
        }

        // Global averages for horizontal dotted lines
        val finalAvgConsumption = if (consumptionPoints.isNotEmpty()) consumptionPoints.map { it.value }.average() else 0.0
        val finalAvgPrice = if (pricePoints.isNotEmpty()) pricePoints.map { it.value }.average() else 0.0

        ChartData(
            consumptionPoints = consumptionPoints,
            avgConsumption = finalAvgConsumption,
            distancePoints = distancePoints,
            pricePoints = pricePoints,
            avgPrice = finalAvgPrice
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChartData())

    private fun getCutoffTimestamp(period: ChartPeriod): Long {
        if (period == ChartPeriod.ALL) return 0L
        val cal = Calendar.getInstance()
        when (period) {
            ChartPeriod.THREE_MONTHS -> cal.add(Calendar.MONTH, -3)
            ChartPeriod.SIX_MONTHS -> cal.add(Calendar.MONTH, -6)
            ChartPeriod.ONE_YEAR -> cal.add(Calendar.YEAR, -1)
            else -> {}
        }
        return cal.timeInMillis
    }
}

data class ChartData(
    val consumptionPoints: List<ConsumptionPoint> = emptyList(),
    val avgConsumption: Double = 0.0,
    val distancePoints: List<DistancePoint> = emptyList(),
    val pricePoints: List<PricePoint> = emptyList(),
    val avgPrice: Double = 0.0
)
