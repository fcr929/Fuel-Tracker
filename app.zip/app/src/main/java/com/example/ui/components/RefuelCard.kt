package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.example.R
import com.example.data.database.entities.Refuel
import com.example.data.database.entities.Vehicle
import com.example.utils.DateFormatter
import com.example.utils.NumberFormatter
import com.example.utils.UnitConverter
import com.example.utils.VehicleVisuals

@Composable
fun RefuelCard(
    refuel: Refuel,
    vehicle: Vehicle,
    kmSincePrevious: Long?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    userUnits: com.example.data.datastore.UserUnits = com.example.data.datastore.UserUnits()
) {
    val vehicleColor = VehicleVisuals.parseColor(vehicle.color, MaterialTheme.colorScheme.primary)
    val vehicleIcon = VehicleVisuals.getIconVector(vehicle.icon)

    val isLight = MaterialTheme.colorScheme.background == Color(0xFFFDF8F6)
    val cardBorderColor = if (isLight) Color(0xFFF1ECE9) else Color(0xFF334155)

    // Convert values on-the-fly for presentation only
    val dispVolume = UnitConverter.convertVolume(refuel.liters, userUnits.volumeUnit)
    val dispOdometer = UnitConverter.convertDistance(refuel.odometer.toDouble(), userUnits.distanceUnit).toLong()
    val dispKmSincePrevious = if (kmSincePrevious != null) {
        UnitConverter.convertDistance(kmSincePrevious.toDouble(), userUnits.distanceUnit).toLong()
    } else null
    val dispPricePerUnit = UnitConverter.convertPricePerUnit(refuel.pricePerLiter, userUnits.volumeUnit)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("refuel_card_${refuel.id}")
            .clip(RoundedCornerShape(24.dp))
            .border(1.dp, cardBorderColor, RoundedCornerShape(24.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .height(IntrinsicSize.Min)
                .fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(6.dp)
                    .background(vehicleColor)
            )

            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(vehicleColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = vehicleIcon,
                        contentDescription = null,
                        tint = vehicleColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = vehicle.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f, fill = false),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        val badgeText = if (refuel.isFull) stringResource(R.string.badge_full) else stringResource(R.string.badge_partial)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (refuel.isFull) MaterialTheme.colorScheme.primaryContainer else Color(0xFFFF9800).copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = badgeText,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (refuel.isFull) MaterialTheme.colorScheme.onPrimaryContainer else Color(0xFFD47A00)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = DateFormatter.formatDateTime(refuel.date),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = NumberFormatter.formatVolume(dispVolume, userUnits.volumeUnit),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "$dispOdometer ${userUnits.distanceUnit}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = NumberFormatter.formatPrice(refuel.priceTotal, userUnits.currencySymbol),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = NumberFormatter.formatPricePerUnit(dispPricePerUnit, userUnits.currencySymbol, userUnits.volumeUnit),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (dispKmSincePrevious != null || refuel.location.isNotEmpty() || refuel.notes.isNotEmpty()) {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 8.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                if (dispKmSincePrevious != null) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "+$dispKmSincePrevious ${userUnits.distanceUnit}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                if (refuel.location.isNotEmpty()) {
                                    Icon(
                                        imageVector = Icons.Default.PinDrop,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = refuel.location,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            
                            if (refuel.notes.isNotEmpty()) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = "Nota opcional",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
