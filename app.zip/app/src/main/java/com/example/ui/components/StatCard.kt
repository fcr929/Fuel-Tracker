package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    supportingText: String? = null
) {
    // Determine light context using the primary color brightness
    val isLight = MaterialTheme.colorScheme.background == Color(0xFFFDF8F6)

    // Configuration according to theme instructions
    val (containerBg, contentShape, borderStroke, primaryColorHex, titleColor) = when {
        title.contains("Consumo", ignoreCase = true) -> {
            val bgCol = if (isLight) Color(0xFFFFFFFF) else Color(0xFF1E293B)
            val borderCol = if (isLight) Color(0xFFF1ECE9) else Color(0xFF334155)
            val textCol = if (isLight) Color(0xFF006A6A) else Color(0xFF4DB6AC)
            val titCol = if (isLight) Color(0xFF64748B) else Color(0xFF94A3B8)
            FiveTuple(bgCol, RoundedCornerShape(28.dp), borderCol, textCol, titCol)
        }
        title.contains("Gasto", ignoreCase = true) -> {
            val bgCol = if (isLight) Color(0xFFF3F4F1) else Color(0xFF222C28)
            val borderCol = Color.Transparent
            val textCol = if (isLight) Color(0xFF1E293B) else Color(0xFFE2E8F0)
            val titCol = if (isLight) Color(0xFF475569) else Color(0xFF94A3B8)
            FiveTuple(bgCol, RoundedCornerShape(24.dp), borderCol, textCol, titCol)
        }
        title.contains("Distancia", ignoreCase = true) -> {
            // Ice blue highlights for distance tracked
            val bgCol = if (isLight) Color(0xFFECF3FF) else Color(0xFF1E2E4A)
            val borderCol = Color.Transparent
            val textCol = if (isLight) Color(0xFF1E293B) else Color(0xFFE2E8F0)
            val titCol = if (isLight) Color(0xFF1D4ED8) else Color(0xFF3B82F6)
            FiveTuple(bgCol, RoundedCornerShape(24.dp), borderCol, textCol, titCol)
        }
        else -> {
            // General neutral surface
            val bgCol = if (isLight) Color(0xFFFFFFFF) else Color(0xFF1E293B)
            val borderCol = if (isLight) Color(0xFFF1ECE9) else Color(0xFF334155)
            val textCol = if (isLight) Color(0xFF1E293B) else Color(0xFFE2E8F0)
            val titCol = if (isLight) Color(0xFF64748B) else Color(0xFF94A3B8)
            FiveTuple(bgCol, RoundedCornerShape(24.dp), borderCol, textCol, titCol)
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(contentShape)
            .run {
                if (borderStroke != Color.Transparent) {
                    border(1.dp, borderStroke, contentShape)
                } else this
            },
        colors = CardDefaults.cardColors(
            containerColor = containerBg
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (title.contains("Consumo", ignoreCase = true) && isLight) 1.dp else 0.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = titleColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                
                // Segment the number from unit suffix if applicable to keep layouts balanced and professional
                val rawVal = value.trim()
                val parts = rawVal.split(" ")
                val numericPart = parts.firstOrNull() ?: ""
                val unitPart = parts.drop(1).joinToString(" ")

                Row(
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = numericPart,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = primaryColorHex
                    )
                    if (unitPart.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = unitPart,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium
                            ),
                            color = titleColor
                        )
                    }
                }
                
                if (supportingText != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = supportingText,
                        style = MaterialTheme.typography.bodySmall,
                        color = titleColor.copy(alpha = 0.8f)
                    )
                }
            }
            
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isLight) Color(0xFFF1F5F9) else Color(0xFF0F172A)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (title.contains("Consumo", ignoreCase = true)) primaryColorHex else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

private data class FiveTuple(
    val containerBg: Color,
    val shape: RoundedCornerShape,
    val borderStroke: Color,
    val textCol: Color,
    val titleCol: Color
)
