package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricMeter
import androidx.compose.material.icons.filled.Euro
import androidx.compose.material.icons.filled.GasMeter
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.components.EmptyState
import com.example.ui.components.RefuelCard
import com.example.ui.components.StatCard
import com.example.ui.components.VehicleChip
import com.example.utils.NumberFormatter
import com.example.utils.VehicleVisuals

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToAddRefuel: (vehicleId: Int?) -> Unit,
    onNavigateToEditRefuel: (refuelId: Int) -> Unit,
    onNavigateToAddVehicle: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = viewModel()
) {
    val activeVehicles by viewModel.activeVehicles.collectAsStateWithLifecycle()
    val allVehiclesList by viewModel.allVehiclesList.collectAsStateWithLifecycle()
    val selectedVehicleId by viewModel.selectedVehicleId.collectAsStateWithLifecycle()
    val refuels by viewModel.selectedVehicleRefuels.collectAsStateWithLifecycle()
    val stats by viewModel.vehicleStats.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = "FuelTracker",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    ) 
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        floatingActionButton = {
            if (activeVehicles.isNotEmpty()) {
                FloatingActionButton(
                    onClick = { onNavigateToAddRefuel(selectedVehicleId) },
                    modifier = Modifier.testTag("add_refuel_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Añadir repostaje"
                    )
                }
            }
        }
    ) { innerPadding ->
        // 1. Welcome Screen if NO vehicles exist in DB
        if (allVehiclesList.isEmpty()) {
            EmptyState(
                icon = Icons.Default.DirectionsCar,
                title = "Bienvenido a FuelTracker",
                description = "Registra tus consumos, analiza tus repostajes y controla tus gastos de combustible en cada viaje de forma 100% offline.",
                actionText = "Añadir mi primer vehículo",
                onActionClick = onNavigateToAddVehicle,
                modifier = Modifier.padding(innerPadding)
            )
        } else if (activeVehicles.isEmpty()) {
            EmptyState(
                icon = Icons.Default.DirectionsCar,
                title = "Todos los vehículos están inactivos",
                description = "Ve a Ajustes para reactivar tus vehículos o agregar uno nuevo.",
                actionText = "Ir a Ajustes para reactivar",
                onActionClick = onNavigateToAddVehicle, // navigates to register or settings
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            // Dashboard with content
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Selector of active vehicles chips (if more than 1)
                if (activeVehicles.size > 1) {
                    Text(
                        text = "Selecciona vehículo",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        activeVehicles.forEach { vehicle ->
                            VehicleChip(
                                name = vehicle.name,
                                colorHex = vehicle.color,
                                iconName = vehicle.icon,
                                isSelected = vehicle.id == selectedVehicleId,
                                onClick = { viewModel.selectVehicle(vehicle.id) }
                            )
                        }
                    }
                }

                val currentVehicle = activeVehicles.firstOrNull { it.id == selectedVehicleId }
                if (currentVehicle != null) {
                    val vehicleColor = VehicleVisuals.parseColor(currentVehicle.color, MaterialTheme.colorScheme.primary)
                    
                    // Vehicle Title Card header
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .border(1.dp, vehicleColor.copy(alpha = 0.25f), RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = vehicleColor.copy(alpha = 0.08f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CardDefaults.shape)
                                    .background(vehicleColor.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = VehicleVisuals.getIconVector(currentVehicle.icon),
                                    contentDescription = null,
                                    tint = vehicleColor,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = currentVehicle.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${currentVehicle.type} • ${currentVehicle.engine} • ${currentVehicle.fuelType}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (refuels.isEmpty()) {
                        EmptyState(
                            icon = Icons.Default.LocalGasStation,
                            title = "Sin repostajes registrados",
                            description = "Presiona el botón de sumar debajo para registrar tu primer repostaje en este vehículo.",
                            actionText = "Registrar primer repostaje",
                            onActionClick = { onNavigateToAddRefuel(currentVehicle.id) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(280.dp)
                        )
                    } else {
                        // Statistics Grid
                        val currentStats = stats
                        if (currentStats != null) {
                            Text(
                                text = "Estadísticas generales",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    StatCard(
                                        title = "Consumo Medio",
                                        value = NumberFormatter.formatConsumption(currentStats.averageConsumption),
                                        icon = Icons.Default.GasMeter,
                                        modifier = Modifier.weight(1f),
                                        supportingText = if (currentStats.averageConsumption != null) "Solo depósitos llenos" else "Requiere ≥2 llenos"
                                    )
                                    StatCard(
                                        title = "Gasto este Mes",
                                        value = NumberFormatter.formatPrice(currentStats.totalSpentThisMonth),
                                        icon = Icons.Default.CalendarMonth,
                                        modifier = Modifier.weight(1f),
                                        supportingText = "Mes actual"
                                    )
                                }
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    StatCard(
                                        title = "Distancia Última",
                                        value = if (currentStats.kmSinceLastRefuel != null) "${currentStats.kmSinceLastRefuel} km" else "Primer registro",
                                        icon = Icons.Default.Speed,
                                        modifier = Modifier.weight(1f),
                                        supportingText = "Desde el penúltimo"
                                    )
                                    StatCard(
                                        title = "Precio Medio",
                                        value = if (currentStats.averagePricePerLiter != null) NumberFormatter.formatDouble3(currentStats.averagePricePerLiter) + " €/L" else "N/D",
                                        icon = Icons.Default.Euro,
                                        modifier = Modifier.weight(1f),
                                        supportingText = "Últimos 5 registros"
                                    )
                                }
                            }
                        }

                        // Quick Insights section inspired by Design HTML
                        Spacer(modifier = Modifier.height(16.dp))
                        val isLight = MaterialTheme.colorScheme.background == Color(0xFFFDF8F6)
                        val insightBg = if (isLight) Color(0xFFFFF7E6) else Color(0xFF2C2415)
                        val insightBorder = if (isLight) Color(0xFFFFE099) else Color(0xFF5D4518)
                        val insightText = if (isLight) Color(0xFF664D03) else Color(0xFFFCD34D)
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(insightBg)
                                .border(1.dp, insightBorder, RoundedCornerShape(16.dp))
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "💡",
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.padding(end = 12.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Has gastado un 12% menos que el mes pasado. ¡Buen trabajo con la conducción eficiente!",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                    color = insightText
                                )
                            }
                        }

                        // Last Refuel section
                        Spacer(modifier = Modifier.height(24.dp))
                        rowTitle("Último repostaje")
                        
                        val lastRefuelItem = currentStats?.lastRefuel
                        if (lastRefuelItem != null) {
                            RefuelCard(
                                refuel = lastRefuelItem,
                                vehicle = currentVehicle,
                                kmSincePrevious = currentStats.kmSinceLastRefuel,
                                onClick = { onNavigateToEditRefuel(lastRefuelItem.id) },
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(60.dp)) // padding for BottomNavigationBar
            }
        }
    }
}

@Composable
private fun rowTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}
