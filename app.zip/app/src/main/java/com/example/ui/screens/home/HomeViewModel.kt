package com.example.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.DependencyProvider
import com.example.data.database.entities.Refuel
import com.example.data.database.entities.Vehicle
import com.example.data.repository.RefuelRepository
import com.example.data.repository.VehicleRepository
import com.example.domain.usecase.GetStatsUseCase
import com.example.domain.usecase.VehicleStats
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(
    private val themePreferenceManager: com.example.data.datastore.ThemePreferenceManager = DependencyProvider.themePreferenceManager,
    private val vehicleRepository: VehicleRepository = DependencyProvider.vehicleRepository,
    private val refuelRepository: RefuelRepository = DependencyProvider.refuelRepository,
    private val getStatsUseCase: GetStatsUseCase = DependencyProvider.getStatsUseCase
) : ViewModel() {

    val userUnits: StateFlow<com.example.data.datastore.UserUnits> = themePreferenceManager.userUnits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), com.example.data.datastore.UserUnits())

    val activeVehicles: StateFlow<List<Vehicle>> = vehicleRepository.activeVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVehiclesList: StateFlow<List<Vehicle>> = vehicleRepository.allVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedVehicleId = MutableStateFlow<Int?>(null)
    val selectedVehicleId: StateFlow<Int?> = _selectedVehicleId.asStateFlow()

    init {
        viewModelScope.launch {
            activeVehicles.collect { vehicles ->
                if (_selectedVehicleId.value == null && vehicles.isNotEmpty()) {
                    _selectedVehicleId.value = vehicles.first().id
                } else if (vehicles.isNotEmpty() && vehicles.none { it.id == _selectedVehicleId.value }) {
                    _selectedVehicleId.value = vehicles.first().id
                }
            }
        }
    }

    fun selectVehicle(vehicleId: Int) {
        _selectedVehicleId.value = vehicleId
    }

    val selectedVehicleRefuels: StateFlow<List<Refuel>> = _selectedVehicleId
        .flatMapLatest { id ->
            if (id != null) {
                refuelRepository.getRefuelsForVehicle(id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vehicleStats: StateFlow<VehicleStats?> = selectedVehicleRefuels
        .map { refuels ->
            getStatsUseCase.execute(refuels)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}
