package com.example.ui.screens.history

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.DependencyProvider
import com.example.data.datastore.ThemePreferenceManager
import com.example.data.datastore.UserUnits
import com.example.data.database.entities.Refuel
import com.example.data.database.entities.Vehicle
import com.example.data.repository.RefuelRepository
import com.example.data.repository.VehicleRepository
import com.example.domain.usecase.ExportCsvUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.Locale

data class HistoryItem(
    val refuel: Refuel,
    val vehicle: Vehicle,
    val kmSincePrevious: Long?
)

data class MonthYear(
    val month: Int, // 0-11
    val year: Int
) {
    fun getDisplayName(locale: Locale = Locale.getDefault()): String {
        val monthName = DateFormatSymbols(locale).months[month]
        return "${monthName.replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }} $year"
    }
}

class HistoryViewModel(
    private val themePreferenceManager: ThemePreferenceManager = DependencyProvider.themePreferenceManager,
    private val vehicleRepository: VehicleRepository = DependencyProvider.vehicleRepository,
    private val refuelRepository: RefuelRepository = DependencyProvider.refuelRepository,
    private val exportCsvUseCase: ExportCsvUseCase = DependencyProvider.exportCsvUseCase
) : ViewModel() {

    val userUnits: StateFlow<UserUnits> = themePreferenceManager.userUnits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserUnits())

    // Filter states
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedVehicleFilter = MutableStateFlow<Int?>(null)
    val selectedVehicleFilter: StateFlow<Int?> = _selectedVehicleFilter.asStateFlow()

    private val _selectedMonthFilter = MutableStateFlow<MonthYear?>(null)
    val selectedMonthFilter: StateFlow<MonthYear?> = _selectedMonthFilter.asStateFlow()

    val vehiclesList: StateFlow<List<Vehicle>> = vehicleRepository.allVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All mapped history items (with kmSincePrevious computed)
    val allHistoryItems: StateFlow<List<HistoryItem>> = combine(
        refuelRepository.allRefuels,
        vehicleRepository.allVehicles
    ) { refuels, vehicles ->
        val vehiclesMap = vehicles.associateBy { it.id }
        val refuelsByVehicle = refuels.groupBy { it.vehicleId }
        val mappedItems = mutableListOf<HistoryItem>()

        for ((vehicleId, list) in refuelsByVehicle) {
            val vehicle = vehiclesMap[vehicleId] ?: continue
            val sortedAsc = list.sortedBy { it.date }
            for (i in sortedAsc.indices) {
                val current = sortedAsc[i]
                val prev = if (i > 0) sortedAsc[i - 1] else null
                val dist = if (prev != null) current.odometer - prev.odometer else null
                mappedItems.add(HistoryItem(current, vehicle, dist))
            }
        }
        mappedItems.sortedByDescending { it.refuel.date }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Available month-year filters collected from data
    val availableMonthYears: StateFlow<List<MonthYear>> = allHistoryItems
        .map { items ->
            items.map { item ->
                val cal = Calendar.getInstance().apply { timeInMillis = item.refuel.date }
                MonthYear(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR))
            }.distinct().sortedWith(
                compareByDescending<MonthYear> { it.year }.thenByDescending { it.month }
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Final filtered log items
    val filteredHistoryItems: StateFlow<List<HistoryItem>> = combine(
        allHistoryItems,
        _searchQuery,
        _selectedVehicleFilter,
        _selectedMonthFilter
    ) { items, query, vehicleId, monthYear ->
        items.filter { item ->
            val matchesVehicle = (vehicleId == null || item.vehicle.id == vehicleId)
            
            val matchesSearch = if (query.isBlank()) {
                true
            } else {
                val q = query.lowercase()
                item.vehicle.name.lowercase().contains(q) ||
                item.refuel.location.lowercase().contains(q) ||
                item.refuel.notes.lowercase().contains(q)
            }

            val matchesMonth = if (monthYear == null) {
                true
            } else {
                val cal = Calendar.getInstance().apply { timeInMillis = item.refuel.date }
                cal.get(Calendar.MONTH) == monthYear.month && cal.get(Calendar.YEAR) == monthYear.year
            }

            matchesVehicle && matchesSearch && matchesMonth
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectVehicleFilter(vehicleId: Int?) {
        _selectedVehicleFilter.value = vehicleId
    }

    fun selectMonthFilter(monthYear: MonthYear?) {
        _selectedMonthFilter.value = monthYear
    }

    fun deleteRefuel(refuel: Refuel) {
        viewModelScope.launch {
            refuelRepository.delete(refuel)
        }
    }

    // Share currently filtered rows as CSV
    suspend fun getExportFilteredCsvUri(context: Context): Uri? {
        val currentFiltered = filteredHistoryItems.value
        if (currentFiltered.isEmpty()) return null
        
        val refuelsAndVehicles = currentFiltered.map { it.refuel to itemToVehicle(it) }
        
        // Export CSV
        return com.example.utils.CsvExporter.exportToCsvUri(
            context = context,
            refuelsAndVehicles = refuelsAndVehicles,
            calculateUseCase = DependencyProvider.calculateConsumptionUseCase,
            specificVehicleName = if (_selectedVehicleFilter.value != null && vehiclesList.value.isNotEmpty()) {
                vehiclesList.value.firstOrNull { it.id == _selectedVehicleFilter.value }?.name
            } else {
                null
            }
        )
    }

    private fun itemToVehicle(item: HistoryItem): Vehicle = item.vehicle
}
