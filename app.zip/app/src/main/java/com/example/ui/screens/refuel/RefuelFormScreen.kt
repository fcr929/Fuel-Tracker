package com.example.ui.screens.refuel

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.components.EmptyState
import com.example.utils.DateFormatter
import com.example.utils.NumberFormatter
import com.example.utils.VehicleVisuals
import kotlinx.coroutines.launch
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RefuelFormScreen(
    onNavigateBack: () -> Unit,
    passedRefuelId: Int? = null,
    passedVehicleId: Int? = null,
    modifier: Modifier = Modifier,
    viewModel: RefuelFormViewModel = viewModel()
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val activeVehicles by viewModel.activeVehicles.collectAsStateWithLifecycle()
    val userUnits by viewModel.userUnits.collectAsStateWithLifecycle()
    
    var showVehicleDropdown by remember { mutableStateOf(false) }
    var saveError by remember { mutableStateOf<SaveResult.Error?>(null) }
    var showOdometerWarningDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    // Initialize the form state in the ViewModel
    LaunchedEffect(passedRefuelId, passedVehicleId) {
        viewModel.initialize(passedRefuelId = passedRefuelId, passedVehicleId = passedVehicleId)
    }

    // Modal dialogs
    if (saveError != null) {
        val err = saveError!!
        val resolvedText = if (err.formatArg != null) {
            stringResource(err.messageResId, err.formatArg)
        } else {
            stringResource(err.messageResId)
        }
        AlertDialog(
            onDismissRequest = { saveError = null },
            title = { Text(stringResource(R.string.refuel_form_validation_error)) },
            text = { Text(resolvedText) },
            confirmButton = {
                TextButton(onClick = { saveError = null }) {
                    Text(stringResource(R.string.refuel_form_understand))
                }
            }
        )
    }

    if (showOdometerWarningDialog) {
        AlertDialog(
            onDismissRequest = { showOdometerWarningDialog = false },
            title = { Text(stringResource(R.string.refuel_form_odo_warning_title)) },
            text = { 
                Text(
                    stringResource(
                        R.string.refuel_form_odo_warning_desc,
                        viewModel.odometer,
                        viewModel.previousOdometer ?: 0L
                    )
                ) 
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showOdometerWarningDialog = false
                        coroutineScope.launch {
                            val res = viewModel.saveRefuel(bypassOdometerWarning = true)
                            if (res is SaveResult.Success) {
                                onNavigateBack()
                            } else if (res is SaveResult.Error) {
                                saveError = res
                            }
                        }
                    }
                ) {
                    Text(stringResource(R.string.refuel_form_odo_btn_force))
                }
            },
            dismissButton = {
                TextButton(onClick = { showOdometerWarningDialog = false }) {
                    Text(stringResource(R.string.refuel_form_odo_btn_review))
                }
            }
        )
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text(stringResource(R.string.delete_dialog_title)) },
            text = { Text(stringResource(R.string.delete_dialog_desc)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        viewModel.deleteRefuel {
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(stringResource(R.string.delete_dialog_confirm))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text(stringResource(R.string.cancel_button))
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = if (viewModel.isEditMode) stringResource(R.string.refuel_form_edit_title) else stringResource(R.string.refuel_form_new_title),
                        fontWeight = FontWeight.Bold
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (viewModel.isEditMode) {
                        IconButton(
                            onClick = { showDeleteConfirmDialog = true },
                            modifier = Modifier.testTag("delete_refuel_top_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = stringResource(R.string.action_delete),
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        if (activeVehicles.isEmpty()) {
            EmptyState(
                icon = Icons.Default.ArrowBack,
                title = stringResource(R.string.refuel_form_empty_vehicles),
                description = stringResource(R.string.refuel_form_empty_vehicles_desc),
                actionText = stringResource(R.string.action_back),
                onActionClick = onNavigateBack,
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // 1. VEHICLE SELECTOR DROPDOWN
                val selectedVehicle = activeVehicles.firstOrNull { it.id == viewModel.vehicleId }
                if (selectedVehicle != null) {
                    val vehicleColor = VehicleVisuals.parseColor(selectedVehicle.color, MaterialTheme.colorScheme.primary)
                    Text(
                        text = stringResource(R.string.refuel_form_vehicle_label),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Card(
                        onClick = { showVehicleDropdown = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .testTag("vehicle_picker_card"),
                        colors = CardDefaults.cardColors(containerColor = vehicleColor.copy(alpha = 0.08f)),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(vehicleColor.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = VehicleVisuals.getIconVector(selectedVehicle.icon),
                                        contentDescription = null,
                                        tint = vehicleColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(text = selectedVehicle.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    Text(text = selectedVehicle.fuelType, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = stringResource(R.string.refuel_form_choose_vehicle))
                        }
                    }

                    DropdownMenu(
                        expanded = showVehicleDropdown,
                        onDismissRequest = { showVehicleDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        activeVehicles.forEach { vehicle ->
                            DropdownMenuItem(
                                leadingIcon = {
                                    val vColor = VehicleVisuals.parseColor(vehicle.color, MaterialTheme.colorScheme.primary)
                                    Icon(
                                        imageVector = VehicleVisuals.getIconVector(vehicle.icon),
                                        contentDescription = null,
                                        tint = vColor
                                    )
                                },
                                text = { Text("${vehicle.name} (${vehicle.fuelType})") },
                                onClick = {
                                    viewModel.onVehicleSelected(vehicle.id)
                                    showVehicleDropdown = false
                                }
                            )
                        }
                    }
                }

                // 2. DATE AND TIME SELECTOR (Dialog launcher)
                Text(
                    text = stringResource(R.string.refuel_form_date_label),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                OutlinedCard(
                    onClick = {
                        val calendar = Calendar.getInstance().apply { timeInMillis = viewModel.date }
                        DatePickerDialog(
                            context,
                            { _, year, month, day ->
                                calendar.set(Calendar.YEAR, year)
                                calendar.set(Calendar.MONTH, month)
                                calendar.set(Calendar.DAY_OF_MONTH, day)
                                
                                TimePickerDialog(
                                    context,
                                    { _, hour, minute ->
                                        calendar.set(Calendar.HOUR_OF_DAY, hour)
                                        calendar.set(Calendar.MINUTE, minute)
                                        viewModel.date = calendar.timeInMillis
                                    },
                                    calendar.get(Calendar.HOUR_OF_DAY),
                                    calendar.get(Calendar.MINUTE),
                                    true
                                ).show()
                            },
                            calendar.get(Calendar.YEAR),
                            calendar.get(Calendar.MONTH),
                            calendar.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("date_picker_card")
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = DateFormatter.formatDateTime(viewModel.date),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(Icons.Default.CalendarToday, contentDescription = stringResource(R.string.refuel_form_date_desc), tint = MaterialTheme.colorScheme.primary)
                    }
                }

                // 3. KILOMETROS ODOMETRO
                OutlinedTextField(
                    value = viewModel.odometer,
                    onValueChange = { viewModel.odometer = it.filter { char -> char.isDigit() } },
                    label = { Text(stringResource(R.string.refuel_form_odo_label, userUnits.distanceUnit)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text(stringResource(R.string.refuel_form_odo_placeholder)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp)
                        .testTag("odometer_input"),
                    singleLine = true
                )
                // Realtime interval display
                val odoVal = viewModel.odometer.toLongOrNull()
                val prevOdo = viewModel.previousOdometer
                val distanceLabel = when {
                    prevOdo == null -> stringResource(R.string.refuel_form_odo_help_first)
                    odoVal != null -> {
                        val diff = odoVal - prevOdo
                        if (diff >= 0) {
                            stringResource(R.string.refuel_form_odo_help_diff, diff.toString(), userUnits.distanceUnit)
                        } else {
                            stringResource(R.string.refuel_form_odo_help_warning, prevOdo.toString(), userUnits.distanceUnit)
                        }
                    }
                    else -> stringResource(R.string.refuel_form_odo_help_last, prevOdo.toString(), userUnits.distanceUnit)
                }
                Text(
                    text = distanceLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (odoVal != null && prevOdo != null && odoVal < prevOdo) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 16.dp, start = 4.dp)
                )

                // 4. LITROS REPOSTADOS
                OutlinedTextField(
                    value = viewModel.liters,
                    onValueChange = { viewModel.onLitersInputChanged(it.replace(',', '.')) },
                    label = { Text(stringResource(R.string.refuel_form_volume_label, userUnits.volumeUnit)) },
                    placeholder = { Text(stringResource(R.string.refuel_form_volume_placeholder)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("liters_input"),
                    singleLine = true
                )

                // 5. DEPÓSITO LLENO TOGGLE
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = stringResource(R.string.refuel_form_is_full), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(text = stringResource(R.string.refuel_form_is_full_desc), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (!viewModel.isFull) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFFF9800).copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.badge_partial),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFD47A00)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Switch(
                            checked = viewModel.isFull,
                            onCheckedChange = { viewModel.isFull = it },
                            modifier = Modifier.testTag("full_tank_switch")
                        )
                    }
                }

                // 6. PRECIO (Bidirectional sync inputs)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = stringResource(R.string.refuel_form_price_section),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = viewModel.priceTotal,
                                onValueChange = { viewModel.onTotalPriceInputChanged(it.replace(',', '.')) },
                                label = { Text(stringResource(R.string.refuel_form_price_total, userUnits.currencySymbol)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("price_total_input"),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = viewModel.pricePerLiter,
                                onValueChange = { viewModel.onPricePerLiterInputChanged(it.replace(',', '.')) },
                                label = { Text(stringResource(R.string.refuel_form_price_unit, userUnits.currencySymbol, userUnits.volumeUnit)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("price_per_liter_input"),
                                singleLine = true
                            )
                        }
                        
                        val doubleLiters = viewModel.liters.toDoubleOrNull() ?: 0.0
                        val valTotal = viewModel.priceTotal.toDoubleOrNull() ?: 0.0
                        val valPerLiter = viewModel.pricePerLiter.toDoubleOrNull() ?: 0.0

                        if (doubleLiters > 0 && (valTotal > 0 || valPerLiter > 0)) {
                            Spacer(modifier = Modifier.height(8.dp))
                            val showCalcLabel = if (valTotal > 0 && valPerLiter == 0.0) {
                                val calcPerLiter = (valTotal / doubleLiters).toBigDecimal().setScale(3, java.math.RoundingMode.HALF_UP).toString()
                                stringResource(R.string.refuel_form_price_calc, calcPerLiter, userUnits.currencySymbol, userUnits.volumeUnit)
                            } else if (valPerLiter > 0 && valTotal == 0.0) {
                                val calcTotal = (valPerLiter * doubleLiters).toBigDecimal().setScale(2, java.math.RoundingMode.HALF_UP).toString()
                                stringResource(R.string.refuel_form_total_calc, calcTotal, userUnits.currencySymbol)
                            } else {
                                ""
                            }
                            if (showCalcLabel.isNotEmpty()) {
                                Text(
                                    text = showCalcLabel,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // 7. LUGAR / GASOLINERA
                OutlinedTextField(
                    value = viewModel.location,
                    onValueChange = { viewModel.location = it },
                    label = { Text(stringResource(R.string.refuel_form_location_label)) },
                    leadingIcon = { Icon(Icons.Default.PinDrop, contentDescription = null) },
                    placeholder = { Text(stringResource(R.string.refuel_form_location_placeholder)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .testTag("location_input"),
                    singleLine = true
                )
                // Historically used locations quick-chips
                if (viewModel.locationSuggestions.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        viewModel.locationSuggestions.forEach { suggestion ->
                            val isSelected = viewModel.location.lowercase() == suggestion.lowercase()
                            AssistChip(
                                onClick = { viewModel.location = suggestion },
                                label = { Text(suggestion) },
                                colors = if (isSelected) {
                                    AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                } else {
                                    AssistChipDefaults.assistChipColors()
                                }
                            )
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // 8. ANOTACIÓN notes
                OutlinedTextField(
                    value = viewModel.notes,
                    onValueChange = { viewModel.notes = it },
                    label = { Text(stringResource(R.string.refuel_form_notes_label)) },
                    placeholder = { Text(stringResource(R.string.refuel_form_notes_placeholder)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .padding(bottom = 24.dp)
                        .testTag("notes_input")
                )

                // BOTONES CONTROL
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("cancel_refuel_button")
                    ) {
                        Text(stringResource(R.string.cancel_button))
                    }
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val res = viewModel.saveRefuel(bypassOdometerWarning = false)
                                when (res) {
                                    is SaveResult.Success -> onNavigateBack()
                                    is SaveResult.OdometerWarning -> showOdometerWarningDialog = true
                                    is SaveResult.Error -> saveError = res
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("save_refuel_button")
                    ) {
                        Text(stringResource(R.string.refuel_form_save_btn))
                    }
                }
            }
        }
    }
}
