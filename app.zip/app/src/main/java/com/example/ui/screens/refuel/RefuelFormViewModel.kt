package com.example.ui.screens.refuel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.DependencyProvider
import com.example.R
import com.example.data.database.entities.Refuel
import com.example.data.database.entities.Vehicle
import com.example.data.repository.RefuelRepository
import com.example.data.repository.VehicleRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode

enum class PriceFieldEdited {
    TOTAL, PER_LITER, NONE
}

class RefuelFormViewModel(
    private val themePreferenceManager: com.example.data.datastore.ThemePreferenceManager = DependencyProvider.themePreferenceManager,
    private val vehicleRepository: VehicleRepository = DependencyProvider.vehicleRepository,
    private val refuelRepository: RefuelRepository = DependencyProvider.refuelRepository
) : ViewModel() {

    // UI form states
    var refuelId by mutableStateOf<Int?>(null)
        private set
    var isEditMode by mutableStateOf(false)
        private set

    val userUnits: StateFlow<com.example.data.datastore.UserUnits> = themePreferenceManager.userUnits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), com.example.data.datastore.UserUnits())

    var vehicleId by mutableStateOf<Int?>(null)
    var date by mutableStateOf(System.currentTimeMillis())
    var odometer by mutableStateOf("")
    var liters by mutableStateOf("")
    var isFull by mutableStateOf(true)
    var priceTotal by mutableStateOf("")
    var pricePerLiter by mutableStateOf("")
    var location by mutableStateOf("")
    var notes by mutableStateOf("")

    private var lastPriceFieldEdited = PriceFieldEdited.NONE

    // Helpers for warning, calculation, and autocomplete
    var previousOdometer by mutableStateOf<Long?>(null)
        private set
    var locationSuggestions by mutableStateOf<List<String>>(emptyList())
        private set

    val activeVehicles: StateFlow<List<Vehicle>> = vehicleRepository.activeVehicles
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    fun initialize(passedRefuelId: Int?, passedVehicleId: Int?) {
        viewModelScope.launch {
            val vehicles = activeVehicles.first()
            
            if (passedRefuelId != null) {
                // Edit Mode
                val refuel = refuelRepository.getRefuelById(passedRefuelId)
                if (refuel != null) {
                    refuelId = refuel.id
                    isEditMode = true
                    vehicleId = refuel.vehicleId
                    date = refuel.date
                    odometer = refuel.odometer.toString()
                    liters = refuel.liters.toString()
                    isFull = refuel.isFull
                    priceTotal = refuel.priceTotal.toString()
                    pricePerLiter = refuel.pricePerLiter.toString()
                    location = refuel.location
                    notes = refuel.notes
                    lastPriceFieldEdited = PriceFieldEdited.TOTAL
                    
                    loadPreviousOdometerAndSuggestions(refuel.vehicleId, refuel.id)
                }
            } else {
                // Add Mode
                isEditMode = false
                date = System.currentTimeMillis()
                vehicleId = passedVehicleId ?: vehicles.firstOrNull()?.id
                if (vehicleId != null) {
                    loadPreviousOdometerAndSuggestions(vehicleId!!, null)
                }
            }
        }
    }

    fun onVehicleSelected(id: Int) {
        vehicleId = id
        loadPreviousOdometerAndSuggestions(id, refuelId)
    }

    private fun loadPreviousOdometerAndSuggestions(vId: Int, currentRefuelId: Int?) {
        viewModelScope.launch {
            val refuels = refuelRepository.getRefuelsForVehicle(vId).first()
            
            // Filter out current editing refuel to find the "real" previous chronologically
            val otherRefuels = if (currentRefuelId != null) {
                refuels.filter { it.id != currentRefuelId }
            } else {
                refuels
            }

            // Sorted chronologically descending, the previous refuel's odometer is the head
            previousOdometer = otherRefuels.firstOrNull()?.odometer

            // Autocomplete suggestions for location (distinct locations used globally for this vehicle + overall)
            val globalRefuels = refuelRepository.allRefuels.first()
            val localLocs = otherRefuels.map { it.location }.filter { it.isNotBlank() }
            val globalLocs = globalRefuels.map { it.location }.filter { it.isNotBlank() }
            locationSuggestions = (localLocs + globalLocs).distinct().take(5)
        }
    }

    // Linked price fields bidirectional calculations
    fun onLitersInputChanged(value: String) {
        liters = value
        recalculatePrices()
    }

    fun onTotalPriceInputChanged(value: String) {
        priceTotal = value
        lastPriceFieldEdited = PriceFieldEdited.TOTAL
        recalculatePrices()
    }

    fun onPricePerLiterInputChanged(value: String) {
        pricePerLiter = value
        lastPriceFieldEdited = PriceFieldEdited.PER_LITER
        recalculatePrices()
    }

    private fun recalculatePrices() {
        val l = liters.toDoubleOrNull() ?: return
        if (l <= 0) return

        when (lastPriceFieldEdited) {
            PriceFieldEdited.TOTAL -> {
                val total = priceTotal.toDoubleOrNull() ?: return
                if (total >= 0) {
                    pricePerLiter = BigDecimal(total / l)
                        .setScale(3, RoundingMode.HALF_UP)
                        .toString()
                }
            }
            PriceFieldEdited.PER_LITER -> {
                val perLiter = pricePerLiter.toDoubleOrNull() ?: return
                if (perLiter >= 0) {
                    priceTotal = BigDecimal(perLiter * l)
                        .setScale(2, RoundingMode.HALF_UP)
                        .toString()
                }
            }
            else -> {}
        }
    }

    // Save with validations.
    // Returns null if success, or failure resource id, or "ODOMETER_WARNING" if odometer is lower than previous.
    suspend fun saveRefuel(bypassOdometerWarning: Boolean = false): SaveResult {
        val vId = vehicleId ?: return SaveResult.Error(R.string.val_err_select_vehicle)
        val dateVal = date
        val litersVal = liters.toDoubleOrNull() ?: return SaveResult.Error(R.string.val_err_liters)
        if (litersVal <= 0) return SaveResult.Error(R.string.val_err_liters)

        val odometerVal = odometer.toLongOrNull() ?: return SaveResult.Error(R.string.val_err_odometer)
        if (odometerVal < 0) return SaveResult.Error(R.string.val_err_odometer_negative)

        // Verify odometer chronological order
        val prevOdo = previousOdometer
        if (prevOdo != null && odometerVal < prevOdo && !bypassOdometerWarning) {
            return SaveResult.OdometerWarning
        }

        // Price calculations fallback/validation
        var total = priceTotal.toDoubleOrNull() ?: 0.0
        var perL = pricePerLiter.toDoubleOrNull() ?: 0.0

        if (total <= 0 && perL <= 0) {
            return SaveResult.Error(R.string.val_err_price_invalid)
        }

        if (total > 0 && perL <= 0) {
            perL = BigDecimal(total / litersVal).setScale(3, RoundingMode.HALF_UP).toDouble()
        } else if (perL > 0 && total <= 0) {
            total = BigDecimal(perL * litersVal).setScale(2, RoundingMode.HALF_UP).toDouble()
        }

        val refuelToSave = Refuel(
            id = refuelId ?: 0,
            vehicleId = vId,
            date = dateVal,
            liters = litersVal,
            isFull = isFull,
            priceTotal = total,
            pricePerLiter = perL,
            odometer = odometerVal,
            location = location.trim(),
            notes = notes.trim(),
            updatedAt = System.currentTimeMillis()
        )

        return try {
            if (isEditMode) {
                refuelRepository.update(refuelToSave)
            } else {
                refuelRepository.insert(refuelToSave)
            }
            SaveResult.Success
        } catch (e: Exception) {
            SaveResult.Error(R.string.val_err_save_db, e.message)
        }
    }

    fun deleteRefuel(onSuccess: () -> Unit) {
        val id = refuelId ?: return
        viewModelScope.launch {
            try {
                refuelRepository.deleteById(id)
                onSuccess()
            } catch (e: Exception) {
                // ignore or handle
            }
        }
    }
}

sealed interface SaveResult {
    object Success : SaveResult
    object OdometerWarning : SaveResult
    data class Error(val messageResId: Int, val formatArg: String? = null) : SaveResult
}
