package com.example.ui.screens.settings

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.datastore.AppTheme
import com.example.data.database.entities.Vehicle
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.res.stringResource
import androidx.compose.material.icons.filled.Email
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.font.FontStyle
import com.example.R
import com.example.utils.VehicleVisuals
import kotlinx.coroutines.launch
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items

data class CurrencyOption(val symbol: String, val name: String, val flag: String, val code: String)

val currencyOptions = listOf(
    CurrencyOption("€", "Euro", "🇪🇺", "EUR"),
    CurrencyOption("$", "Dólar estadounidense", "🇺🇸", "USD"),
    CurrencyOption("£", "Libra esterlina", "🇬🇧", "GBP"),
    CurrencyOption("$", "Peso mexicano", "🇲🇽", "MXN"),
    CurrencyOption("$", "Peso colombiano", "🇨🇴", "COP"),
    CurrencyOption("$", "Peso argentino", "🇦🇷", "ARS"),
    CurrencyOption("$", "Peso chileno", "🇨🇱", "CLP"),
    CurrencyOption("R$", "Real brasileño", "🇧🇷", "BRL"),
    CurrencyOption("S/.", "Sol peruano", "🇵🇪", "PEN"),
    CurrencyOption("$", "Dólar canadiense", "🇨🇦", "CAD"),
    CurrencyOption("$", "Dólar australiano", "🇦🇺", "AUD"),
    CurrencyOption("¥", "Yen japonés", "🇯🇵", "JPY"),
    CurrencyOption("CHF", "Franco suizo", "🇨🇭", "CHF"),
    CurrencyOption("¥", "Yuan chino", "🇨🇳", "CNY")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateToAddVehicle: () -> Unit,
    onNavigateToEditVehicle: (vehicleId: Int) -> Unit,
    viewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val currentTheme by viewModel.themePreference.collectAsStateWithLifecycle()
    val vehicles by viewModel.allVehicles.collectAsStateWithLifecycle()

    var showVehicleExportDialog by remember { mutableStateOf(false) }

    // Import states from ViewModel
    val isImporting by viewModel.isImporting.collectAsStateWithLifecycle()
    val importErrorMsg by viewModel.importErrorMsg.collectAsStateWithLifecycle()
    val importInfoMsg by viewModel.importInfoMsg.collectAsStateWithLifecycle()
    val importPreviewState by viewModel.importPreviewState.collectAsStateWithLifecycle()
    val importSuccessMessage by viewModel.importSuccessMessage.collectAsStateWithLifecycle()

    var selectedStrategy by remember { mutableStateOf(ImportStrategy.ADD_NO_DUP) }
    val snackbarHostState = remember { SnackbarHostState() }

    val csvImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.prepareImport(context, uri)
        }
    }

    LaunchedEffect(importSuccessMessage) {
        if (importSuccessMessage != null) {
            snackbarHostState.showSnackbar(
                message = importSuccessMessage!!,
                duration = SnackbarDuration.Long
            )
            viewModel.dismissSuccessMessage()
        }
    }

    // Dialog for exporting CSV of a specific vehicle
    if (showVehicleExportDialog) {
        AlertDialog(
            onDismissRequest = { showVehicleExportDialog = false },
            title = { Text(stringResource(R.string.export_by_vehicle_title)) },
            text = {
                if (vehicles.isEmpty()) {
                    Text(stringResource(R.string.export_by_vehicle_empty))
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.export_by_vehicle_select))
                        vehicles.forEach { vehicle ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showVehicleExportDialog = false
                                        coroutineScope.launch {
                                            val uri = viewModel.exportVehicleHistory(context, vehicle.id)
                                            if (uri != null) {
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/csv"
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, context.getString(R.string.export_by_vehicle_chooser)))
                                            }
                                        }
                                    }
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(VehicleVisuals.parseColor(vehicle.color))
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(vehicle.name, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showVehicleExportDialog = false }) {
                    Text(stringResource(R.string.close_dialog))
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = stringResource(R.string.settings_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    ) 
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // SECTION 1: VEHICLES
            SettingsSectionHeader(title = stringResource(R.string.settings_registered_vehicles))
            
            if (vehicles.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stringResource(R.string.no_saved_vehicles),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                vehicles.forEach { vehicle ->
                    val colorObj = VehicleVisuals.parseColor(vehicle.color, MaterialTheme.colorScheme.primary)
                    Card(
                        onClick = { onNavigateToEditVehicle(vehicle.id) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .testTag("vehicle_settings_item_${vehicle.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (vehicle.isActive) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(colorObj.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = VehicleVisuals.getIconVector(vehicle.icon),
                                        contentDescription = null,
                                        tint = if (vehicle.isActive) colorObj else Color.Gray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = vehicle.name,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (vehicle.isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                    )
                                    Text(
                                        text = "${vehicle.type} • ${vehicle.fuelType}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            // Visibility toggle button (Active/Deactive)
                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        viewModel.toggleVehicleActive(vehicle)
                                    }
                                },
                                modifier = Modifier.testTag("vehicle_active_toggle_${vehicle.id}")
                            ) {
                                Icon(
                                    imageVector = if (vehicle.isActive) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = stringResource(R.string.change_vehicle_state),
                                    tint = if (vehicle.isActive) MaterialTheme.colorScheme.primary else Color.Gray
                                )
                            }
                        }
                    }
                }
            }

            Button(
                onClick = onNavigateToAddVehicle,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .testTag("add_vehicle_button"),
                colors = ButtonDefaults.filledTonalButtonColors()
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.add_vehicle))
            }

            // SECTION: UNIDADES
            val userUnits by viewModel.userUnits.collectAsStateWithLifecycle()
            var showCurrencyDialog by remember { mutableStateOf(false) }

            if (showCurrencyDialog) {
                var currencySearchQuery by remember { mutableStateOf("") }
                val filteredOptions = remember(currencySearchQuery) {
                    currencyOptions.filter {
                        it.name.contains(currencySearchQuery, ignoreCase = true) ||
                        it.code.contains(currencySearchQuery, ignoreCase = true) ||
                        it.symbol.contains(currencySearchQuery, ignoreCase = true)
                    }
                }

                AlertDialog(
                    onDismissRequest = { showCurrencyDialog = false },
                    title = { Text(stringResource(R.string.select_currency)) },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = currencySearchQuery,
                                onValueChange = { currencySearchQuery = it },
                                placeholder = { Text(stringResource(R.string.search_currency_placeholder)) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )
                            
                            Box(modifier = Modifier.height(260.dp)) {
                                LazyColumn(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    items(filteredOptions) { option ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    viewModel.setCurrency(option.symbol, option.name, option.flag)
                                                    showCurrencyDialog = false
                                                }
                                                .padding(vertical = 10.dp, horizontal = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(option.flag, style = MaterialTheme.typography.titleMedium)
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(option.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                                Text("${option.code} (${option.symbol})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { showCurrencyDialog = false }) {
                            Text(stringResource(R.string.import_cancel))
                        }
                    }
                )
            }

            SettingsSectionHeader(title = stringResource(R.string.settings_section_units))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Currency Selection Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCurrencyDialog = true }
                            .padding(vertical = 8.dp)
                            .testTag("currency_row"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = stringResource(R.string.currency_title),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${userUnits.currencyFlag} ${userUnits.currencyName} (${userUnits.currencySymbol})",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = stringResource(R.string.select_currency),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    // Distance Unit Selection
                    Text(
                        text = stringResource(R.string.distance_unit_title),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    SingleChoiceSegmentedButtonRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        val distanceOptions = listOf("km" to "Kilómetros (km)", "mi" to "Millas (mi)")
                        distanceOptions.forEachIndexed { index, pair ->
                            SegmentedButton(
                                selected = userUnits.distanceUnit == pair.first,
                                onClick = { viewModel.setDistanceUnit(pair.first) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = distanceOptions.size),
                                modifier = Modifier.testTag("distance_unit_btn_${pair.first}")
                            ) {
                                Text(text = pair.second, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    // Volume Unit Selection
                    Text(
                        text = stringResource(R.string.volume_unit_title),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        val volumeOptions = listOf("L" to "Litros (L)", "gal_us" to "Galones US (gal)", "gal_uk" to "Galones UK (gal)")
                        volumeOptions.forEachIndexed { index, pair ->
                            SegmentedButton(
                                selected = userUnits.volumeUnit == pair.first,
                                onClick = { viewModel.setVolumeUnit(pair.first) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = volumeOptions.size),
                                modifier = Modifier.testTag("volume_unit_btn_${pair.first}")
                            ) {
                                Text(text = pair.second, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            // SECTION 2: THEME APARIENCIA
            SettingsSectionHeader(title = stringResource(R.string.settings_section_theme))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.theme_app),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        AppTheme.values().forEachIndexed { index, themeOption ->
                            val label = when (themeOption) {
                                AppTheme.SYSTEM -> stringResource(R.string.theme_auto)
                                AppTheme.LIGHT -> stringResource(R.string.theme_light)
                                AppTheme.DARK -> stringResource(R.string.theme_dark)
                            }
                            SegmentedButton(
                                selected = currentTheme == themeOption,
                                onClick = { viewModel.selectTheme(themeOption) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = AppTheme.values().size),
                                modifier = Modifier.testTag("theme_btn_${themeOption.name.lowercase()}")
                            ) {
                                Text(text = label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            // SECTION 3: EXPORTS
            SettingsSectionHeader(title = stringResource(R.string.settings_section_data))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val uri = viewModel.exportAllHistory(context)
                                if (uri != null) {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/csv"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, context.getString(R.string.export_chooser_title)))
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_all_csv_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.export_all))
                    }

                    OutlinedButton(
                        onClick = { showVehicleExportDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_by_vehicle_csv_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.export_by_vehicle_title))
                    }

                    FilledTonalButton(
                        onClick = { csvImportLauncher.launch("text/*") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("import_csv_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.import_csv))
                    }
                }
            }

            // SECTION 4: ABOUT DE
            SettingsSectionHeader(title = stringResource(R.string.about_title))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 80.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // BLOQUE 1 — fila horizontal (Row, alineación vertical centrada)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "FuelTracker v1.0.11",
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // BLOQUE 2 — fila horizontal (Row, alineación vertical centrada)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("👷", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.about_author),
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = stringResource(R.string.about_author_title),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "pcr382.apps@gmail.com",
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier
                                    .clickable {
                                        try {
                                            val intent = Intent(Intent.ACTION_SENDTO).apply {
                                                data = Uri.parse("mailto:")
                                                putExtra(Intent.EXTRA_EMAIL, arrayOf("pcr382.apps@gmail.com"))
                                                putExtra(Intent.EXTRA_SUBJECT, "FuelTracker - Feedback")
                                            }
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            // fail gracefully
                                        }
                                    }
                                    .padding(vertical = 2.dp)
                            )
                            Text(
                                text = stringResource(R.string.about_feedback_sub),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    // CSV IMPORT SYSTEM DIALOGS
    if (isImporting) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text(stringResource(R.string.processing_data)) },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            },
            confirmButton = {}
        )
    }

    if (importErrorMsg != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissError() },
            title = { Text(stringResource(R.string.import_error_dialog_title)) },
            text = { Text(importErrorMsg ?: "") },
            confirmButton = {
                TextButton(onClick = { viewModel.dismissError() }) {
                    Text(stringResource(R.string.refuel_form_understand))
                }
            }
        )
    }

    if (importInfoMsg != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissInfo() },
            title = { Text(stringResource(R.string.info_title)) },
            text = { Text(importInfoMsg ?: "") },
            confirmButton = {
                TextButton(onClick = { viewModel.dismissInfo() }) {
                    Text(stringResource(R.string.btn_agree))
                }
            }
        )
    }

    if (importPreviewState != null) {
        val preview = importPreviewState!!
        val isEs = java.util.Locale.getDefault().language.lowercase() == "es"
        
        val previewTitle = stringResource(R.string.import_preview_title)
        val recordsFound = if (isEs) "Registros encontrados en el archivo: ${preview.records.size}" else "Records found in file: ${preview.records.size}"
        val vehiclesDetected = if (isEs) "Vehículos detectados:" else "Detected vehicles:"
        val questionExisting = if (isEs) "¿Qué hacer con los registros existentes?" else "What to do with existing records?"
        
        val attentionReplace = if (isEs) {
            "⚠️ ATENCIÓN: Se eliminará todo el historial existente en la app para los vehículos detectados (${preview.detectedVehicles.joinToString()}) antes de importar los del CSV. Esta acción no se puede deshacer."
        } else {
            "⚠️ WARNING: All existing history in the app for the detected vehicles (${preview.detectedVehicles.joinToString()}) will be deleted before importing from the CSV. This action cannot be undone."
        }

        AlertDialog(
            onDismissRequest = { viewModel.dismissPreview() },
            title = { Text(previewTitle, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = recordsFound,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = vehiclesDetected,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        preview.detectedVehicles.forEach { vehicleName ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.secondary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = vehicleName,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Text(
                        text = questionExisting,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Opción A
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStrategy = ImportStrategy.ADD_NO_DUP }
                        ) {
                            RadioButton(
                                selected = selectedStrategy == ImportStrategy.ADD_NO_DUP,
                                onClick = { selectedStrategy = ImportStrategy.ADD_NO_DUP },
                                modifier = Modifier.testTag("import_strategy_nodup")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = stringResource(R.string.import_strategy_nodup_title),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = stringResource(R.string.import_strategy_nodup_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Opción B
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStrategy = ImportStrategy.ADD_ALL }
                        ) {
                            RadioButton(
                                selected = selectedStrategy == ImportStrategy.ADD_ALL,
                                onClick = { selectedStrategy = ImportStrategy.ADD_ALL },
                                modifier = Modifier.testTag("import_strategy_addall")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = stringResource(R.string.import_strategy_addall_title),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = stringResource(R.string.import_strategy_addall_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Opción C
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStrategy = ImportStrategy.REPLACE }
                        ) {
                            RadioButton(
                                selected = selectedStrategy == ImportStrategy.REPLACE,
                                onClick = { selectedStrategy = ImportStrategy.REPLACE },
                                modifier = Modifier.testTag("import_strategy_replace")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = stringResource(R.string.import_strategy_replace_title),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = stringResource(R.string.import_strategy_replace_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (selectedStrategy == ImportStrategy.REPLACE) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = attentionReplace,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.executeImport(context, selectedStrategy)
                    },
                    colors = if (selectedStrategy == ImportStrategy.REPLACE) {
                        ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
					} else {
                        ButtonDefaults.buttonColors()
                    },
                    modifier = Modifier.testTag("confirm_import_button")
                ) {
                    Text(stringResource(R.string.import_confirm))
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.dismissPreview() },
                    modifier = Modifier.testTag("cancel_import_button")
                ) {
                    Text(stringResource(R.string.import_cancel))
                }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 12.dp, top = 8.dp)
    )
}

// --------------------- SUB-FORM COMPOSABLE: VEHICLE FORM ---------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleFormScreen(
    onNavigateBack: () -> Unit,
    vehicleIdToEdit: Int? = null,
    viewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("Coche") }
    var engine by remember { mutableStateOf("") }
    var selectedFuel by remember { mutableStateOf("Gasolina 95") }
    var colorHex by remember { mutableStateOf("#4CAF50") }
    var customColorHexInput by remember { mutableStateOf("") }
    var selectedIcon by remember { mutableStateOf("ic_car") }
    var isActive by remember { mutableStateOf(true) }

    var showValidationDialog by remember { mutableStateOf(false) }

    // Dropdown selectors states
    var typeDropdownExpanded by remember { mutableStateOf(false) }
    var fuelDropdownExpanded by remember { mutableStateOf(false) }

    val vehicleTypes = listOf("Coche", "Moto", "Furgoneta", "Camión", "Quad", "Otro")
    val fuelTypes = listOf("Gasolina 95", "Gasolina 98", "Gasolina 98+", "Diésel", "Diésel+", "GLP", "GNC", "Eléctrico", "Híbrido", "Otro")

    // If editing, load original details from the database
    LaunchedEffect(vehicleIdToEdit) {
        if (vehicleIdToEdit != null && vehicleIdToEdit > 0) {
            val v = viewModel.getVehicleById(vehicleIdToEdit)
            if (v != null) {
                name = v.name
                selectedType = v.type
                engine = v.engine
                selectedFuel = v.fuelType
                colorHex = v.color
                customColorHexInput = v.color
                selectedIcon = v.icon
                isActive = v.isActive
            }
        }
    }

    if (showValidationDialog) {
        AlertDialog(
            onDismissRequest = { showValidationDialog = false },
            title = { Text(stringResource(R.string.vehicle_name_required_title)) },
            text = { Text(stringResource(R.string.vehicle_name_required_desc)) },
            confirmButton = {
                TextButton(onClick = { showValidationDialog = false }) {
                    Text(stringResource(R.string.btn_agree))
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = if (vehicleIdToEdit != null) stringResource(R.string.edit_vehicle_title) else stringResource(R.string.new_vehicle_title),
                        fontWeight = FontWeight.Bold
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // 1. VEHICLE NAME (Mandatory)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(stringResource(R.string.vehicle_label_name)) },
                placeholder = { Text(stringResource(R.string.vehicle_placeholder_name)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .testTag("vehicle_name_input"),
                singleLine = true
            )

            // 2. VEHICLE TYPE (Dropdown Selector)
            Box(modifier = Modifier.padding(bottom = 16.dp)) {
                OutlinedTextField(
                    value = selectedType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(stringResource(R.string.vehicle_label_type)) },
                    trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { typeDropdownExpanded = true }
                        .testTag("vehicle_type_dropdown"),
                    enabled = false,
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                // Overlay click catcher due to textfield disable
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .clickable { typeDropdownExpanded = true }
                )
                DropdownMenu(
                    expanded = typeDropdownExpanded,
                    onDismissRequest = { typeDropdownExpanded = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    vehicleTypes.forEach { type ->
                        DropdownMenuItem(
                            text = { Text(type) },
                            onClick = {
                                selectedType = type
                                typeDropdownExpanded = false
                                // Auto-assign a matching preset icon for convenience
                                selectedIcon = when (type.lowercase()) {
                                    "coche" -> "ic_car"
                                    "moto" -> "ic_motorcycle"
                                    "furgoneta" -> "ic_van"
                                    "camión" -> "ic_truck"
                                    "quad" -> "ic_quad"
                                    else -> "ic_car"
                                }
                            }
                        )
                    }
                }
            }

            // 3. VEHICLE ENGINE/DISPLACEMENT
            OutlinedTextField(
                value = engine,
                onValueChange = { engine = it },
                label = { Text(stringResource(R.string.vehicle_label_engine)) },
                placeholder = { Text(stringResource(R.string.vehicle_placeholder_engine)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .testTag("vehicle_engine_input"),
                singleLine = true
            )

            // 4. FUEL TYPE TYPE (Dropdown Selector)
            Box(modifier = Modifier.padding(bottom = 16.dp)) {
                OutlinedTextField(
                    value = selectedFuel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(stringResource(R.string.vehicle_label_fuel)) },
                    trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { fuelDropdownExpanded = true }
                        .testTag("vehicle_fuel_dropdown"),
                    enabled = false,
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .clickable { fuelDropdownExpanded = true }
                )
                DropdownMenu(
                    expanded = fuelDropdownExpanded,
                    onDismissRequest = { fuelDropdownExpanded = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    fuelTypes.forEach { fuel ->
                        DropdownMenuItem(
                            text = { Text(fuel) },
                            onClick = {
                                selectedFuel = fuel
                                fuelDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            // 5. COLOR PICKER PALETTE
            Text(
                text = stringResource(R.string.vehicle_color_ident),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Render circular indicators
                VehicleVisuals.presetColors.take(6).forEach { (hexCode, name) ->
                    val isSelected = colorHex.lowercase() == hexCode.lowercase()
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(android.graphics.Color.parseColor(hexCode)))
                            .border(
                                width = if (isSelected) 3.dp else 0.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { colorHex = hexCode }
                            .testTag("color_preset_$name")
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VehicleVisuals.presetColors.drop(6).forEach { (hexCode, name) ->
                    val isSelected = colorHex.lowercase() == hexCode.lowercase()
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(android.graphics.Color.parseColor(hexCode)))
                            .border(
                                width = if (isSelected) 3.dp else 0.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { colorHex = hexCode }
                            .testTag("color_preset_$name")
                    )
                }
            }
            // Custom Color input box
            OutlinedTextField(
                value = customColorHexInput,
                onValueChange = { 
                    customColorHexInput = it
                    if (it.startsWith("#") && (it.length == 4 || it.length == 7)) {
                        colorHex = it
                    }
                },
                label = { Text(stringResource(R.string.vehicle_label_color)) },
                placeholder = { Text(stringResource(R.string.vehicle_placeholder_color)) },
                leadingIcon = { Icon(Icons.Default.ColorLens, contentDescription = null, tint = VehicleVisuals.parseColor(colorHex)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .testTag("vehicle_custom_color_hex"),
                singleLine = true
            )

            // 6. ICON VISUAL SHAPE LIST LIST
            Text(
                text = stringResource(R.string.vehicle_icon_ident),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                VehicleVisuals.presetIcons.forEach { (iconKey, labelName) ->
                    val isSelected = selectedIcon == iconKey
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) {
                                    VehicleVisuals.parseColor(colorHex).copy(alpha = 0.15f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                }
                            )
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) VehicleVisuals.parseColor(colorHex) else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedIcon = iconKey }
                            .testTag("icon_preset_$iconKey"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = VehicleVisuals.getIconVector(iconKey),
                            contentDescription = labelName,
                            tint = if (isSelected) VehicleVisuals.parseColor(colorHex) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 7. ACTIVE TOGGLE SWIFT
            if (vehicleIdToEdit != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = stringResource(R.string.vehicle_active_label), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(text = stringResource(R.string.vehicle_active_desc), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = isActive,
                        onCheckedChange = { isActive = it },
                        modifier = Modifier.testTag("vehicle_active_switch")
                    )
                }
            }

            // CONTROLS save and cancel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("cancel_vehicle_button")
                ) {
                    Text(stringResource(R.string.cancel_button))
                }
                Button(
                    onClick = {
                        if (name.isBlank()) {
                            showValidationDialog = true
                        } else {
                            coroutineScope.launch {
                                val success = viewModel.saveVehicle(
                                    id = vehicleIdToEdit ?: 0,
                                    name = name,
                                    type = selectedType,
                                    engine = engine,
                                    fuelType = selectedFuel,
                                    colorHex = colorHex,
                                    iconName = selectedIcon,
                                    isActive = isActive
                                )
                                if (success) {
                                    onNavigateBack()
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_vehicle_button")
                ) {
                    Text(stringResource(R.string.save_button))
                }
            }
        }
    }
}
