package com.example.ui.screens.settings

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.datastore.AppTheme
import com.example.data.database.entities.Vehicle
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Email
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.font.FontStyle
import com.example.utils.VehicleVisuals
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateToAddVehicle: () -> Unit,
    onNavigateToEditVehicle: (vehicleId: Int) -> Unit,
    viewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val currentTheme by viewModel.themePreference.collectAsStateWithLifecycle()
    val vehicles by viewModel.allVehicles.collectAsStateWithLifecycle()

    var showVehicleExportDialog by remember { mutableStateOf(false) }

    // Import states from ViewModel
    val isImporting by viewModel.isImporting.collectAsStateWithLifecycle()
    val importErrorMsg by viewModel.importErrorMsg.collectAsStateWithLifecycle()
    val importInfoMsg by viewModel.importInfoMsg.collectAsStateWithLifecycle()
    val importPreviewState by viewModel.importPreviewState.collectAsStateWithLifecycle()
    val importSuccessMessage by viewModel.importSuccessMessage.collectAsStateWithLifecycle()

    var selectedStrategy by remember { mutableStateOf(ImportStrategy.ADD_NO_DUP) }
    val snackbarHostState = remember { SnackbarHostState() }

    val csvImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.prepareImport(context, uri)
        }
    }

    LaunchedEffect(importSuccessMessage) {
        if (importSuccessMessage != null) {
            snackbarHostState.showSnackbar(
                message = importSuccessMessage!!,
                duration = SnackbarDuration.Long
            )
            viewModel.dismissSuccessMessage()
        }
    }

    // Dialog for exporting CSV of a specific vehicle
    if (showVehicleExportDialog) {
        AlertDialog(
            onDismissRequest = { showVehicleExportDialog = false },
            title = { Text("Exportar por vehículo") },
            text = {
                if (vehicles.isEmpty()) {
                    Text("No hay vehículos registrados aún.")
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Selecciona el vehículo que deseas exportar:")
                        vehicles.forEach { vehicle ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showVehicleExportDialog = false
                                        coroutineScope.launch {
                                            val uri = viewModel.exportVehicleHistory(context, vehicle.id)
                                            if (uri != null) {
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/csv"
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "Exportar vehículo CSV"))
                                            }
                                        }
                                    }
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(VehicleVisuals.parseColor(vehicle.color))
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(vehicle.name, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showVehicleExportDialog = false }) {
                    Text("Cerrar")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = "Ajustes",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    ) 
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // SECTION 1: VEHICLES
            SettingsSectionHeader(title = "Vehículos registrados")
            
            if (vehicles.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No hay vehículos guardados",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                vehicles.forEach { vehicle ->
                    val colorObj = VehicleVisuals.parseColor(vehicle.color, MaterialTheme.colorScheme.primary)
                    Card(
                        onClick = { onNavigateToEditVehicle(vehicle.id) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .testTag("vehicle_settings_item_${vehicle.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (vehicle.isActive) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(colorObj.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = VehicleVisuals.getIconVector(vehicle.icon),
                                        contentDescription = null,
                                        tint = if (vehicle.isActive) colorObj else Color.Gray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = vehicle.name,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (vehicle.isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                    )
                                    Text(
                                        text = "${vehicle.type} • ${vehicle.fuelType}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            // Visibility toggle button (Active/Deactive)
                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        viewModel.toggleVehicleActive(vehicle)
                                    }
                                },
                                modifier = Modifier.testTag("vehicle_active_toggle_${vehicle.id}")
                            ) {
                                Icon(
                                    imageVector = if (vehicle.isActive) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Cambiar estado de vehículo",
                                    tint = if (vehicle.isActive) MaterialTheme.colorScheme.primary else Color.Gray
                                )
                            }
                        }
                    }
                }
            }

            Button(
                onClick = onNavigateToAddVehicle,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .testTag("add_vehicle_button"),
                colors = ButtonDefaults.filledTonalButtonColors()
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Añadir vehículo")
            }

            // SECTION 2: THEME APARIENCIA
            SettingsSectionHeader(title = "Apariencia")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Tema de la aplicación",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        AppTheme.values().forEachIndexed { index, themeOption ->
                            val label = when (themeOption) {
                                AppTheme.SYSTEM -> "Auto"
                                AppTheme.LIGHT -> "Claro"
                                AppTheme.DARK -> "Oscuro"
                            }
                            SegmentedButton(
                                selected = currentTheme == themeOption,
                                onClick = { viewModel.selectTheme(themeOption) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = AppTheme.values().size),
                                modifier = Modifier.testTag("theme_btn_${themeOption.name.lowercase()}")
                            ) {
                                Text(text = label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            // SECTION 3: EXPORTS
            SettingsSectionHeader(title = "Datos")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val uri = viewModel.exportAllHistory(context)
                                if (uri != null) {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/csv"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Exportar TODO el Historial"))
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_all_csv_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Exportar TODO el historial en CSV")
                    }

                    OutlinedButton(
                        onClick = { showVehicleExportDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_by_vehicle_csv_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Exportar historial por vehículo")
                    }

                    FilledTonalButton(
                        onClick = { csvImportLauncher.launch("text/*") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("import_csv_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Importar historial desde CSV")
                    }
                }
            }

            // SECTION 4: ABOUT DE
            SettingsSectionHeader(title = "Acerca de")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 80.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(text = "FuelTracker v1.0.0", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                        Text(
                            text = "Almacenamiento local SQLite con cifrado nativo. App optimizada de repostajes y control de consumo.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Desarrollado por Paco Carreño",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Ingeniero electrónico y desarrollador de software libre",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable {
                                    try {
                                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                                            data = Uri.parse("mailto:pcr382.apps@gmail.com")
                                            putExtra(Intent.EXTRA_SUBJECT, "FuelTracker - Feedback")
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        // fail gracefully
                                    }
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = "Email de contacto",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "pcr382.apps@gmail.com",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                ),
                                textDecoration = TextDecoration.Underline
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Apoyo y feedback bienvenidos",
                            style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    // CSV IMPORT SYSTEM DIALOGS
    if (isImporting) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Procesando datos...") },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            },
            confirmButton = {}
        )
    }

    if (importErrorMsg != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissError() },
            title = { Text("Error de importación") },
            text = { Text(importErrorMsg ?: "") },
            confirmButton = {
                TextButton(onClick = { viewModel.dismissError() }) {
                    Text("Entendido")
                }
            }
        )
    }

    if (importInfoMsg != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissInfo() },
            title = { Text("Información") },
            text = { Text(importInfoMsg ?: "") },
            confirmButton = {
                TextButton(onClick = { viewModel.dismissInfo() }) {
                    Text("De acuerdo")
                }
            }
        )
    }

    if (importPreviewState != null) {
        val preview = importPreviewState!!
        AlertDialog(
            onDismissRequest = { viewModel.dismissPreview() },
            title = { Text("Previsualización de importación", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Registros encontrados en el archivo: ${preview.records.size}",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "Vehículos detectados:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        preview.detectedVehicles.forEach { vehicleName ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.secondary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = vehicleName,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Text(
                        text = "¿Qué hacer con los registros existentes?",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Opción A
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStrategy = ImportStrategy.ADD_NO_DUP }
                        ) {
                            RadioButton(
                                selected = selectedStrategy == ImportStrategy.ADD_NO_DUP,
                                onClick = { selectedStrategy = ImportStrategy.ADD_NO_DUP },
                                modifier = Modifier.testTag("import_strategy_nodup")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Añadir sin duplicar (Recomendado)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Evita duplicar la combinación de vehículo, fecha y odómetro exacta.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Opción B
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStrategy = ImportStrategy.ADD_ALL }
                        ) {
                            RadioButton(
                                selected = selectedStrategy == ImportStrategy.ADD_ALL,
                                onClick = { selectedStrategy = ImportStrategy.ADD_ALL },
                                modifier = Modifier.testTag("import_strategy_addall")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Añadir todos",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Importa todos los registros sin comprobar si ya existen.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Opción C
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStrategy = ImportStrategy.REPLACE }
                        ) {
                            RadioButton(
                                selected = selectedStrategy == ImportStrategy.REPLACE,
                                onClick = { selectedStrategy = ImportStrategy.REPLACE },
                                modifier = Modifier.testTag("import_strategy_replace")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Reemplazar todo",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Sustituye todo el historial de los vehículos detectados.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (selectedStrategy == ImportStrategy.REPLACE) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "⚠️ ATENCIÓN: Se eliminará todo el historial existente en la app para los vehículos detectados (${preview.detectedVehicles.joinToString()}) antes de importar los del CSV. Esta acción no se puede deshacer.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.executeImport(context, selectedStrategy)
                    },
                    colors = if (selectedStrategy == ImportStrategy.REPLACE) {
                        ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    } else {
                        ButtonDefaults.buttonColors()
                    },
                    modifier = Modifier.testTag("confirm_import_button")
                ) {
                    Text("Importar")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.dismissPreview() },
                    modifier = Modifier.testTag("cancel_import_button")
                ) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 12.dp, top = 8.dp)
    )
}

// --------------------- SUB-FORM COMPOSABLE: VEHICLE FORM ---------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleFormScreen(
    onNavigateBack: () -> Unit,
    vehicleIdToEdit: Int? = null,
    viewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("Coche") }
    var engine by remember { mutableStateOf("") }
    var selectedFuel by remember { mutableStateOf("Gasolina 95") }
    var colorHex by remember { mutableStateOf("#4CAF50") }
    var customColorHexInput by remember { mutableStateOf("") }
    var selectedIcon by remember { mutableStateOf("ic_car") }
    var isActive by remember { mutableStateOf(true) }

    var showValidationDialog by remember { mutableStateOf(false) }

    // Dropdown selectors states
    var typeDropdownExpanded by remember { mutableStateOf(false) }
    var fuelDropdownExpanded by remember { mutableStateOf(false) }

    val vehicleTypes = listOf("Coche", "Moto", "Furgoneta", "Camión", "Quad", "Otro")
    val fuelTypes = listOf("Gasolina 95", "Gasolina 98", "Gasolina 98+", "Diésel", "Diésel+", "GLP", "GNC", "Eléctrico", "Híbrido", "Otro")

    // If editing, load original details from the database
    LaunchedEffect(vehicleIdToEdit) {
        if (vehicleIdToEdit != null && vehicleIdToEdit > 0) {
            val v = viewModel.getVehicleById(vehicleIdToEdit)
            if (v != null) {
                name = v.name
                selectedType = v.type
                engine = v.engine
                selectedFuel = v.fuelType
                colorHex = v.color
                customColorHexInput = v.color
                selectedIcon = v.icon
                isActive = v.isActive
            }
        }
    }

    if (showValidationDialog) {
        AlertDialog(
            onDismissRequest = { showValidationDialog = false },
            title = { Text("Falta el nombre") },
            text = { Text("Por favor, ingresa el nombre identificativo de tu vehículo antes de continuar.") },
            confirmButton = {
                TextButton(onClick = { showValidationDialog = false }) {
                    Text("De acuerdo")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = if (vehicleIdToEdit != null) "Editar vehículo" else "Nuevo vehículo",
                        fontWeight = FontWeight.Bold
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Atrás")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // 1. VEHICLE NAME (Mandatory)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre del vehículo (Obligatorio)") },
                placeholder = { Text("Ej: Mi Coche, PCX de Juan...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .testTag("vehicle_name_input"),
                singleLine = true
            )

            // 2. VEHICLE TYPE (Dropdown Selector)
            Box(modifier = Modifier.padding(bottom = 16.dp)) {
                OutlinedTextField(
                    value = selectedType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Tipo de vehículo") },
                    trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { typeDropdownExpanded = true }
                        .testTag("vehicle_type_dropdown"),
                    enabled = false,
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                // Overlay click catcher due to textfield disable
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .clickable { typeDropdownExpanded = true }
                )
                DropdownMenu(
                    expanded = typeDropdownExpanded,
                    onDismissRequest = { typeDropdownExpanded = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    vehicleTypes.forEach { type ->
                        DropdownMenuItem(
                            text = { Text(type) },
                            onClick = {
                                selectedType = type
                                typeDropdownExpanded = false
                                // Auto-assign a matching preset icon for convenience
                                selectedIcon = when (type.lowercase()) {
                                    "coche" -> "ic_car"
                                    "moto" -> "ic_motorcycle"
                                    "furgoneta" -> "ic_van"
                                    "camión" -> "ic_truck"
                                    "quad" -> "ic_quad"
                                    else -> "ic_car"
                                }
                            }
                        )
                    }
                }
            }

            // 3. VEHICLE ENGINE/DISPLACEMENT
            OutlinedTextField(
                value = engine,
                onValueChange = { engine = it },
                label = { Text("Motor / Cilindrada") },
                placeholder = { Text("Ej: 1.6 TDI, 125cc, Eléctrico 150kW") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .testTag("vehicle_engine_input"),
                singleLine = true
            )

            // 4. FUEL TYPE TYPE (Dropdown Selector)
            Box(modifier = Modifier.padding(bottom = 16.dp)) {
                OutlinedTextField(
                    value = selectedFuel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Tipo de combustible") },
                    trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { fuelDropdownExpanded = true }
                        .testTag("vehicle_fuel_dropdown"),
                    enabled = false,
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .clickable { fuelDropdownExpanded = true }
                )
                DropdownMenu(
                    expanded = fuelDropdownExpanded,
                    onDismissRequest = { fuelDropdownExpanded = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    fuelTypes.forEach { fuel ->
                        DropdownMenuItem(
                            text = { Text(fuel) },
                            onClick = {
                                selectedFuel = fuel
                                fuelDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            // 5. COLOR PICKER PALETTE
            Text(
                text = "Color identificativo",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Render circular indicators
                VehicleVisuals.presetColors.take(6).forEach { (hexCode, name) ->
                    val isSelected = colorHex.lowercase() == hexCode.lowercase()
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(android.graphics.Color.parseColor(hexCode)))
                            .border(
                                width = if (isSelected) 3.dp else 0.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { colorHex = hexCode }
                            .testTag("color_preset_$name")
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VehicleVisuals.presetColors.drop(6).forEach { (hexCode, name) ->
                    val isSelected = colorHex.lowercase() == hexCode.lowercase()
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(android.graphics.Color.parseColor(hexCode)))
                            .border(
                                width = if (isSelected) 3.dp else 0.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { colorHex = hexCode }
                            .testTag("color_preset_$name")
                    )
                }
            }
            // Custom Color input box
            OutlinedTextField(
                value = customColorHexInput,
                onValueChange = { 
                    customColorHexInput = it
                    if (it.startsWith("#") && (it.length == 4 || it.length == 7)) {
                        colorHex = it
                    }
                },
                label = { Text("Color personalizado (HEX)") },
                placeholder = { Text("Ej: #FF5722") },
                leadingIcon = { Icon(Icons.Default.ColorLens, contentDescription = null, tint = VehicleVisuals.parseColor(colorHex)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .testTag("vehicle_custom_color_hex"),
                singleLine = true
            )

            // 6. ICON VISUAL SHAPE LIST LIST
            Text(
                text = "Icono identificativo",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                VehicleVisuals.presetIcons.forEach { (iconKey, labelName) ->
                    val isSelected = selectedIcon == iconKey
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) {
                                    VehicleVisuals.parseColor(colorHex).copy(alpha = 0.15f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                }
                            )
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) VehicleVisuals.parseColor(colorHex) else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedIcon = iconKey }
                            .testTag("icon_preset_$iconKey"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = VehicleVisuals.getIconVector(iconKey),
                            contentDescription = labelName,
                            tint = if (isSelected) VehicleVisuals.parseColor(colorHex) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 7. ACTIVE TOGGLE SWIFT
            if (vehicleIdToEdit != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Vehículo activo", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(text = "Desactiva para ocultarlo en los selectores sin borrar su historial", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = isActive,
                        onCheckedChange = { isActive = it },
                        modifier = Modifier.testTag("vehicle_active_switch")
                    )
                }
            }

            // CONTROLS save and cancel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("cancel_vehicle_button")
                ) {
                    Text("Cancelar")
                }
                Button(
                    onClick = {
                        if (name.isBlank()) {
                            showValidationDialog = true
                        } else {
                            coroutineScope.launch {
                                val success = viewModel.saveVehicle(
                                    id = vehicleIdToEdit ?: 0,
                                    name = name,
                                    type = selectedType,
                                    engine = engine,
                                    fuelType = selectedFuel,
                                    colorHex = colorHex,
                                    iconName = selectedIcon,
                                    isActive = isActive
                                )
                                if (success) {
                                    onNavigateBack()
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_vehicle_button")
                ) {
                    Text("Guardar")
                }
            }
        }
    }
}
