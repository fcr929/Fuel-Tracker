package com.example.ui.screens.charts

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.res.stringResource
import com.example.R
import com.example.ui.components.EmptyState
import com.example.ui.components.VehicleChip
import com.example.utils.DateFormatter
import com.example.utils.NumberFormatter
import com.example.utils.UnitConverter
import com.example.utils.VehicleVisuals

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChartsScreen(
    modifier: Modifier = Modifier,
    viewModel: ChartsViewModel = viewModel()
) {
    val activeVehicles by viewModel.activeVehicles.collectAsStateWithLifecycle()
    val selectedVehicleId by viewModel.selectedVehicleId.collectAsStateWithLifecycle()
    val selectedPeriod by viewModel.selectedPeriod.collectAsStateWithLifecycle()
    val chartData by viewModel.chartData.collectAsStateWithLifecycle()
    val userUnits by viewModel.userUnits.collectAsStateWithLifecycle()

    // Dynamically convert points on the fly for UI presentation only
    val convertedConsumptionPoints = remember(chartData.consumptionPoints, userUnits) {
        chartData.consumptionPoints.map { pt ->
            val convVal = UnitConverter.convertConsumption(pt.value, userUnits.distanceUnit, userUnits.volumeUnit)
            val convKm = UnitConverter.convertDistance(pt.kmTraveled.toDouble(), userUnits.distanceUnit).toLong()
            pt.copy(value = convVal, kmTraveled = convKm)
        }
    }
    val convertedAvgConsumption = remember(chartData.avgConsumption, userUnits) {
        if (chartData.avgConsumption > 0) {
            UnitConverter.convertConsumption(chartData.avgConsumption, userUnits.distanceUnit, userUnits.volumeUnit)
        } else 0.0
    }

    val convertedDistancePoints = remember(chartData.distancePoints, userUnits) {
        chartData.distancePoints.map { pt ->
            val convVal = UnitConverter.convertDistance(pt.value.toDouble(), userUnits.distanceUnit).toLong()
            val convCons = pt.consumptionVal?.let { UnitConverter.convertConsumption(it, userUnits.distanceUnit, userUnits.volumeUnit) }
            
            // Recompute high-consumption indicator relative to converted average consumption
            val isHigher = if (convCons != null && convertedAvgConsumption > 0) {
                convCons > convertedAvgConsumption
            } else null

            pt.copy(value = convVal, consumptionVal = convCons, isHigherThanAvg = isHigher)
        }
    }

    val convertedPricePoints = remember(chartData.pricePoints, userUnits) {
        chartData.pricePoints.map { pt ->
            val convVal = UnitConverter.convertPricePerUnit(pt.value, userUnits.volumeUnit)
            pt.copy(value = convVal)
        }
    }
    val convertedAvgPrice = remember(chartData.avgPrice, userUnits) {
        UnitConverter.convertPricePerUnit(chartData.avgPrice, userUnits.volumeUnit)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = stringResource(R.string.graphics_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    ) 
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        if (activeVehicles.isEmpty()) {
            EmptyState(
                icon = Icons.Default.BarChart,
                title = stringResource(R.string.chart_no_active_vehicles),
                description = stringResource(R.string.chart_no_active_vehicles_desc),
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Vehicle selection row (if more than 1)
                if (activeVehicles.size > 1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        activeVehicles.forEach { vehicle ->
                            VehicleChip(
                                name = vehicle.name,
                                colorHex = vehicle.color,
                                iconName = vehicle.icon,
                                isSelected = vehicle.id == selectedVehicleId,
                                onClick = { viewModel.selectVehicle(vehicle.id) }
                            )
                        }
                    }
                }

                // Timeframe selector segment
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    ChartPeriod.values().forEachIndexed { index, period ->
                        // Dynamically translate period labels if needed, or use period.label
                        // Note: period.label has "3 Meses", "6 Meses", "1 Año", "Todo" in Spanish, but we can also localize them dynamically:
                        val localizedPeriodLabel = when(period) {
                            ChartPeriod.THREE_MONTHS -> stringResource(R.string.chart_period_three_months)
                            ChartPeriod.SIX_MONTHS -> stringResource(R.string.chart_period_six_months)
                            ChartPeriod.ONE_YEAR -> stringResource(R.string.chart_period_year)
                            ChartPeriod.ALL -> stringResource(R.string.chart_period_all)
                        }
                        SegmentedButton(
                            selected = period == selectedPeriod,
                            onClick = { viewModel.selectPeriod(period) },
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = ChartPeriod.values().size)
                        ) {
                            Text(text = localizedPeriodLabel, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                val vehicle = activeVehicles.firstOrNull { it.id == selectedVehicleId }
                if (vehicle != null) {
                    val themeColor = VehicleVisuals.parseColor(vehicle.color, MaterialTheme.colorScheme.primary)

                    if (chartData.pricePoints.isEmpty()) {
                        EmptyState(
                            icon = Icons.Default.BarChart,
                            title = stringResource(R.string.chart_insufficient_data),
                            description = stringResource(R.string.chart_insufficient_data_desc),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                        )
                    } else {
                        // Graph 1: Consumption Line Chart
                        ChartContainer(
                            title = stringResource(R.string.chart_consumption_title, userUnits.consumptionUnit),
                            description = stringResource(R.string.chart_consumption_desc)
                        ) {
                            if (convertedConsumptionPoints.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = stringResource(R.string.chart_consumption_empty),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LineChartCanvas(
                                    points = convertedConsumptionPoints,
                                    averageValue = convertedAvgConsumption,
                                    lineColor = themeColor,
                                    unitLabel = " " + userUnits.consumptionUnit,
                                    userUnits = userUnits
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Graph 2: Distance Traveled Bar Chart
                        ChartContainer(
                            title = stringResource(R.string.chart_distance_title, userUnits.distanceUnit),
                            description = stringResource(R.string.chart_distance_desc)
                        ) {
                            BarChartCanvas(
                                points = convertedDistancePoints,
                                barColor = themeColor,
                                unitLabel = " " + userUnits.distanceUnit,
                                userUnits = userUnits
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Graph 3: Fuel Price Evolution Line & Area Chart
                        ChartContainer(
                            title = stringResource(R.string.chart_price_title, userUnits.currencySymbol, userUnits.volumeUnit),
                            description = stringResource(R.string.chart_price_desc)
                        ) {
                            PriceChartCanvas(
                                points = convertedPricePoints,
                                averageValue = convertedAvgPrice,
                                lineColor = themeColor,
                                unitLabel = " " + userUnits.currencySymbol + "/" + userUnits.volumeUnit,
                                userUnits = userUnits
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun ChartContainer(
    title: String,
    description: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            content()
        }
    }
}

// ------------------- LINE CHART CANVAS (Consumption) -------------------
@Composable
fun LineChartCanvas(
    points: List<ConsumptionPoint>,
    averageValue: Double,
    lineColor: Color,
    unitLabel: String,
    userUnits: com.example.data.datastore.UserUnits
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    
    val minVal = (points.map { it.value }.minOrNull() ?: 0.0) * 0.8
    val maxVal = (points.map { it.value }.maxOrNull() ?: 10.0) * 1.2
    val delta = if (maxVal - minVal == 0.0) 1.0 else maxVal - minVal

    Column {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            val width = size.width
                            val stepX = width / (points.size - 1).coerceAtLeast(1)
                            var closestIdx = 0
                            var closestDist = Float.MAX_VALUE
                            for (i in points.indices) {
                                val pxX = i * stepX
                                val dist = kotlin.math.abs(pxX - offset.x)
                                if (dist < closestDist) {
                                    closestDist = dist
                                    closestIdx = i
                                }
                            }
                            selectedIndex = closestIdx
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val paddingBottom = 20f
                val paddingTop = 10f
                val drawHeight = canvasHeight - paddingBottom - paddingTop

                val stepX = canvasWidth / (points.size - 1).coerceAtLeast(1)

                // Draw Grid Lines helper (Y axis)
                val gridLinesCount = 3
                for (g in 0..gridLinesCount) {
                    val yVal = minVal + (delta * g / gridLinesCount)
                    val pixelY = canvasHeight - paddingBottom - ((yVal - minVal) / delta * drawHeight).toFloat()
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.4f),
                        start = Offset(0f, pixelY),
                        end = Offset(canvasWidth, pixelY),
                        strokeWidth = 1f
                    )
                }

                // Draw general average line (dotted)
                val avgY = canvasHeight - paddingBottom - ((averageValue - minVal) / delta * drawHeight).toFloat()
                drawLine(
                    color = lineColor.copy(alpha = 0.5f),
                    start = Offset(0f, avgY),
                    end = Offset(canvasWidth, avgY),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // Draw Curve / Lines
                val linePath = Path()
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    if (i == 0) {
                        linePath.moveTo(pixelX, pixelY)
                    } else {
                        linePath.lineTo(pixelX, pixelY)
                    }
                }
                drawPath(
                    path = linePath,
                    color = lineColor,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                // Draw circles inside points and highlighted tap index
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    val isTapped = (selectedIndex == i)
                    drawCircle(
                        color = if (isTapped) Color.White else lineColor,
                        radius = if (isTapped) 7.dp.toPx() else 4.dp.toPx(),
                        center = Offset(pixelX, pixelY)
                    )
                    drawCircle(
                        color = lineColor,
                        radius = if (isTapped) 7.dp.toPx() else 4.dp.toPx(),
                        center = Offset(pixelX, pixelY),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }
        }

        // Selected Tooltip Display underneath the graph card
        val activeIdx = selectedIndex
        if (activeIdx != null && activeIdx < points.size) {
            val point = points[activeIdx]
            Card(
                colors = CardDefaults.cardColors(containerColor = lineColor.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = stringResource(R.string.chart_tooltip_date) + ": ${DateFormatter.formatDate(point.date)}", style = MaterialTheme.typography.bodySmall)
                        Text(text = stringResource(R.string.chart_tooltip_segment) + ": ${point.kmTraveled} ${userUnits.distanceUnit}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        text = "${NumberFormatter.formatDouble2(point.value)}$unitLabel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = lineColor
                    )
                }
            }
        } else {
            Text(
                text = stringResource(R.string.chart_help_tap_point),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}

// ------------------- BAR CHART CANVAS (Km distance) -------------------
@Composable
fun BarChartCanvas(
    points: List<DistancePoint>,
    barColor: Color,
    unitLabel: String,
    userUnits: com.example.data.datastore.UserUnits
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val maxVal = (points.map { it.value }.maxOrNull() ?: 500L) * 1.15
    val delta = if (maxVal == 0.0) 1.0 else maxVal.toDouble()

    Column {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            val width = size.width
                            val barWidthStep = width / points.size.coerceAtLeast(1)
                            val tappedIdx = (offset.x / barWidthStep).toInt().coerceIn(0, points.size - 1)
                            selectedIndex = tappedIdx
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val paddingBottom = 20f
                val paddingTop = 10f
                val drawHeight = canvasHeight - paddingBottom - paddingTop

                val barWidthStep = canvasWidth / points.size.coerceAtLeast(1)
                val individualBarWidth = barWidthStep * 0.75f

                // Draw grid lines
                val gridLinesCount = 3
                for (g in 0..gridLinesCount) {
                    val yVal = maxVal * g / gridLinesCount
                    val pixelY = canvasHeight - paddingBottom - (yVal / delta * drawHeight).toFloat()
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.4f),
                        start = Offset(0f, pixelY),
                        end = Offset(canvasWidth, pixelY),
                        strokeWidth = 1f
                    )
                }

                // Draw Bars
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * barWidthStep + (barWidthStep - individualBarWidth) / 2
                    val pixelYHeight = (pt.value.toDouble() / delta * drawHeight).toFloat()
                    val pixelY = canvasHeight - paddingBottom - pixelYHeight

                    // Color based on rules: green (< avg), red (> avg), gray (partial)
                    val drawColor = when (pt.isHigherThanAvg) {
                        true -> Color(0xFFE53935) // Red higher consumption
                        false -> Color(0xFF43A047) // Green lower consumption
                        null -> Color.Gray.copy(alpha = 0.5f) // Gray partial
                    }

                    val isTapped = (selectedIndex == i)
                    drawRect(
                        color = if (isTapped) drawColor.copy(alpha = 0.6f) else drawColor,
                        topLeft = Offset(pixelX, pixelY),
                        size = Size(individualBarWidth, pixelYHeight)
                    )
                }
            }
        }

        // Details Tooltip
        val activeIdx = selectedIndex
        if (activeIdx != null && activeIdx < points.size) {
            val point = points[activeIdx]
            val drawColor = when (point.isHigherThanAvg) {
                true -> Color(0xFFE53935)
                false -> Color(0xFF43A047)
                null -> Color.Gray
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = drawColor.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = stringResource(R.string.chart_tooltip_date) + ": ${DateFormatter.formatDate(point.date)}", style = MaterialTheme.typography.bodySmall)
                        val detailsType = if (point.isFull) stringResource(R.string.badge_full) else stringResource(R.string.badge_partial)
                        val consLabel = if (point.consumptionVal != null) {
                            stringResource(R.string.chart_tooltip_consumption) + ": ${NumberFormatter.formatDouble2(point.consumptionVal)} ${userUnits.consumptionUnit}"
                        } else {
                            stringResource(R.string.chart_tooltip_consumption) + ": " + stringResource(R.string.stats_not_available)
                        }
                        Text(text = stringResource(R.string.chart_tooltip_refuel_type) + ": $detailsType • $consLabel", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        text = "${point.value}$unitLabel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = drawColor
                    )
                }
            }
        } else {
            Text(
                text = stringResource(R.string.chart_help_tap_bar),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}

// ------------------- PRICE EVOLUTION LINE & AREA CANVAS -------------------
@Composable
fun PriceChartCanvas(
    points: List<PricePoint>,
    averageValue: Double,
    lineColor: Color,
    unitLabel: String,
    userUnits: com.example.data.datastore.UserUnits
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val minVal = (points.map { it.value }.minOrNull() ?: 1.0) * 0.95
    val maxVal = (points.map { it.value }.maxOrNull() ?: 2.0) * 1.05
    val delta = if (maxVal - minVal == 0.0) 1.0 else maxVal - minVal

    Column {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            val width = size.width
                            val stepX = width / (points.size - 1).coerceAtLeast(1)
                            var closestIdx = 0
                            var closestDist = Float.MAX_VALUE
                            for (i in points.indices) {
                                val pxX = i * stepX
                                val dist = kotlin.math.abs(pxX - offset.x)
                                if (dist < closestDist) {
                                    closestDist = dist
                                    closestIdx = i
                                }
                            }
                            selectedIndex = closestIdx
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val paddingBottom = 20f
                val paddingTop = 10f
                val drawHeight = canvasHeight - paddingBottom - paddingTop

                val stepX = canvasWidth / (points.size - 1).coerceAtLeast(1)

                // Grid Y helper
                val gridLinesCount = 3
                for (g in 0..gridLinesCount) {
                    val yVal = minVal + (delta * g / gridLinesCount)
                    val pixelY = canvasHeight - paddingBottom - ((yVal - minVal) / delta * drawHeight).toFloat()
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.4f),
                        start = Offset(0f, pixelY),
                        end = Offset(canvasWidth, pixelY),
                        strokeWidth = 1f
                    )
                }

                // Average line (dotted)
                val avgY = canvasHeight - paddingBottom - ((averageValue - minVal) / delta * drawHeight).toFloat()
                drawLine(
                    color = lineColor.copy(alpha = 0.5f),
                    start = Offset(0f, avgY),
                    end = Offset(canvasWidth, avgY),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // Area under the Price Curve (filled)
                val areaPath = Path()
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    if (i == 0) {
                        areaPath.moveTo(pixelX, canvasHeight - paddingBottom)
                        areaPath.lineTo(pixelX, pixelY)
                    } else {
                        areaPath.lineTo(pixelX, pixelY)
                    }
                    if (i == points.size - 1) {
                        areaPath.lineTo(pixelX, canvasHeight - paddingBottom)
                    }
                }
                areaPath.close()

                drawPath(
                    path = areaPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(lineColor.copy(alpha = 0.35f), lineColor.copy(alpha = 0.01f)),
                        startY = paddingTop,
                        endY = canvasHeight - paddingBottom
                    )
                )

                // High Contrast Line path overlay
                val linePath = Path()
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    if (i == 0) {
                        linePath.moveTo(pixelX, pixelY)
                    } else {
                        linePath.lineTo(pixelX, pixelY)
                    }
                }
                drawPath(
                    path = linePath,
                    color = lineColor,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                // Dot overlay
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    val isTapped = (selectedIndex == i)
                    drawCircle(
                        color = if (isTapped) Color.White else lineColor,
                        radius = if (isTapped) 7.dp.toPx() else 4.dp.toPx(),
                        center = Offset(pixelX, pixelY)
                    )
                    drawCircle(
                        color = lineColor,
                        radius = if (isTapped) 7.dp.toPx() else 4.dp.toPx(),
                        center = Offset(pixelX, pixelY),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }
        }

        // Price Tooltip Display
        val activeIdx = selectedIndex
        if (activeIdx != null && activeIdx < points.size) {
            val point = points[activeIdx]
            Card(
                colors = CardDefaults.cardColors(containerColor = lineColor.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = stringResource(R.string.chart_tooltip_date) + ": ${DateFormatter.formatDate(point.date)}", style = MaterialTheme.typography.bodySmall)
                        val loc = point.location.ifBlank { stringResource(R.string.chart_not_registered_location) }
                        Text(text = stringResource(R.string.chart_tooltip_location) + ": $loc", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        text = "${NumberFormatter.formatDouble3(point.value)}$unitLabel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = lineColor
                    )
                }
            }
        } else {
            Text(
                text = stringResource(R.string.chart_help_tap_price),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}
