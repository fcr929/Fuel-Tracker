package com.example.ui.screens.charts

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.EmptyState
import com.example.ui.components.VehicleChip
import com.example.utils.DateFormatter
import com.example.utils.NumberFormatter
import com.example.utils.VehicleVisuals

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChartsScreen(
    modifier: Modifier = Modifier,
    viewModel: ChartsViewModel = viewModel()
) {
    val activeVehicles by viewModel.activeVehicles.collectAsStateWithLifecycle()
    val selectedVehicleId by viewModel.selectedVehicleId.collectAsStateWithLifecycle()
    val selectedPeriod by viewModel.selectedPeriod.collectAsStateWithLifecycle()
    val chartData by viewModel.chartData.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = "Gráficas",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    ) 
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        if (activeVehicles.isEmpty()) {
            EmptyState(
                icon = Icons.Default.BarChart,
                title = "Sin vehículos activos",
                description = "Por favor, agrega o activa al menos un vehículo en Ajustes para visualizar el análisis gráfico.",
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Vehicle selection row (if more than 1)
                if (activeVehicles.size > 1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        activeVehicles.forEach { vehicle ->
                            VehicleChip(
                                name = vehicle.name,
                                colorHex = vehicle.color,
                                iconName = vehicle.icon,
                                isSelected = vehicle.id == selectedVehicleId,
                                onClick = { viewModel.selectVehicle(vehicle.id) }
                            )
                        }
                    }
                }

                // Timeframe selector segment
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    ChartPeriod.values().forEachIndexed { index, period ->
                        SegmentedButton(
                            selected = period == selectedPeriod,
                            onClick = { viewModel.selectPeriod(period) },
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = ChartPeriod.values().size)
                        ) {
                            Text(text = period.label, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                val vehicle = activeVehicles.firstOrNull { it.id == selectedVehicleId }
                if (vehicle != null) {
                    val themeColor = VehicleVisuals.parseColor(vehicle.color, MaterialTheme.colorScheme.primary)

                    if (chartData.pricePoints.isEmpty()) {
                        EmptyState(
                            icon = Icons.Default.BarChart,
                            title = "Datos insuficientes para este período",
                            description = "Ingresa más repostajes con fechas dentro del período seleccionado.",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                        )
                    } else {
                        // Graph 1: Consumption Line Chart
                        ChartContainer(
                            title = "Consumo a los 100 km (L/100km)",
                            description = "Evolución de consumos (depósitos llenos). La línea punteada indica la media general."
                        ) {
                            if (chartData.consumptionPoints.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Requiere al menos 2 depósitos llenos para calcular.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LineChartCanvas(
                                    points = chartData.consumptionPoints,
                                    averageValue = chartData.avgConsumption,
                                    lineColor = themeColor,
                                    unitLabel = " L/100km"
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Graph 2: Distance Traveled Bar Chart
                        ChartContainer(
                            title = "Kilómetros entre repostajes",
                            description = "Distancia en km recorrida entre cargas de combustible. Color: verde (< media), rojo (> media), gris (parcial)."
                        ) {
                            BarChartCanvas(
                                points = chartData.distancePoints,
                                barColor = themeColor,
                                unitLabel = " km"
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Graph 3: Fuel Price Evolution Line & Area Chart
                        ChartContainer(
                            title = "Evolución del precio por litro (€/L)",
                            description = "Evolución del precio unitario pagado. El sombreado representa el área de la curva."
                        ) {
                            PriceChartCanvas(
                                points = chartData.pricePoints,
                                averageValue = chartData.avgPrice,
                                lineColor = themeColor,
                                unitLabel = " €/L"
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun ChartContainer(
    title: String,
    description: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            content()
        }
    }
}

// ------------------- LINE CHART CANVAS (Consumption) -------------------
@Composable
fun LineChartCanvas(
    points: List<ConsumptionPoint>,
    averageValue: Double,
    lineColor: Color,
    unitLabel: String
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    
    val minVal = (points.map { it.value }.minOrNull() ?: 0.0) * 0.8
    val maxVal = (points.map { it.value }.maxOrNull() ?: 10.0) * 1.2
    val delta = if (maxVal - minVal == 0.0) 1.0 else maxVal - minVal

    Column {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            val width = size.width
                            val stepX = width / (points.size - 1).coerceAtLeast(1)
                            var closestIdx = 0
                            var closestDist = Float.MAX_VALUE
                            for (i in points.indices) {
                                val pxX = i * stepX
                                val dist = kotlin.math.abs(pxX - offset.x)
                                if (dist < closestDist) {
                                    closestDist = dist
                                    closestIdx = i
                                }
                            }
                            selectedIndex = closestIdx
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val paddingBottom = 20f
                val paddingTop = 10f
                val drawHeight = canvasHeight - paddingBottom - paddingTop

                val stepX = canvasWidth / (points.size - 1).coerceAtLeast(1)

                // Draw Grid Lines helper (Y axis)
                val gridLinesCount = 3
                for (g in 0..gridLinesCount) {
                    val yVal = minVal + (delta * g / gridLinesCount)
                    val pixelY = canvasHeight - paddingBottom - ((yVal - minVal) / delta * drawHeight).toFloat()
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.4f),
                        start = Offset(0f, pixelY),
                        end = Offset(canvasWidth, pixelY),
                        strokeWidth = 1f
                    )
                }

                // Draw general average line (dotted)
                val avgY = canvasHeight - paddingBottom - ((averageValue - minVal) / delta * drawHeight).toFloat()
                drawLine(
                    color = lineColor.copy(alpha = 0.5f),
                    start = Offset(0f, avgY),
                    end = Offset(canvasWidth, avgY),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // Draw Curve / Lines
                val linePath = Path()
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    if (i == 0) {
                        linePath.moveTo(pixelX, pixelY)
                    } else {
                        linePath.lineTo(pixelX, pixelY)
                    }
                }
                drawPath(
                    path = linePath,
                    color = lineColor,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                // Draw circles inside points and highlighted tap index
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    val isTapped = (selectedIndex == i)
                    drawCircle(
                        color = if (isTapped) Color.White else lineColor,
                        radius = if (isTapped) 7.dp.toPx() else 4.dp.toPx(),
                        center = Offset(pixelX, pixelY)
                    )
                    drawCircle(
                        color = lineColor,
                        radius = if (isTapped) 7.dp.toPx() else 4.dp.toPx(),
                        center = Offset(pixelX, pixelY),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }
        }

        // Selected Tooltip Display underneath the graph card
        val activeIdx = selectedIndex
        if (activeIdx != null && activeIdx < points.size) {
            val point = points[activeIdx]
            Card(
                colors = CardDefaults.cardColors(containerColor = lineColor.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Fecha: ${DateFormatter.formatDate(point.date)}", style = MaterialTheme.typography.bodySmall)
                        Text(text = "Km tramo: ${point.kmTraveled} km", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        text = "${NumberFormatter.formatDouble2(point.value)}$unitLabel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = lineColor
                    )
                }
            }
        } else {
            Text(
                text = "Presiona sobre un punto de la gráfica para ver detalles.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}

// ------------------- BAR CHART CANVAS (Km distance) -------------------
@Composable
fun BarChartCanvas(
    points: List<DistancePoint>,
    barColor: Color,
    unitLabel: String
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val maxVal = (points.map { it.value }.maxOrNull() ?: 500L) * 1.15
    val delta = if (maxVal == 0.0) 1.0 else maxVal.toDouble()

    Column {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            val width = size.width
                            val barWidthStep = width / points.size.coerceAtLeast(1)
                            val tappedIdx = (offset.x / barWidthStep).toInt().coerceIn(0, points.size - 1)
                            selectedIndex = tappedIdx
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val paddingBottom = 20f
                val paddingTop = 10f
                val drawHeight = canvasHeight - paddingBottom - paddingTop

                val barWidthStep = canvasWidth / points.size.coerceAtLeast(1)
                val individualBarWidth = barWidthStep * 0.75f

                // Draw grid lines
                val gridLinesCount = 3
                for (g in 0..gridLinesCount) {
                    val yVal = maxVal * g / gridLinesCount
                    val pixelY = canvasHeight - paddingBottom - (yVal / delta * drawHeight).toFloat()
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.4f),
                        start = Offset(0f, pixelY),
                        end = Offset(canvasWidth, pixelY),
                        strokeWidth = 1f
                    )
                }

                // Draw Bars
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * barWidthStep + (barWidthStep - individualBarWidth) / 2
                    val pixelYHeight = (pt.value.toDouble() / delta * drawHeight).toFloat()
                    val pixelY = canvasHeight - paddingBottom - pixelYHeight

                    // Color based on rules: green (< avg), red (> avg), gray (partial)
                    val drawColor = when (pt.isHigherThanAvg) {
                        true -> Color(0xFFE53935) // Red higher consumption
                        false -> Color(0xFF43A047) // Green lower consumption
                        null -> Color.Gray.copy(alpha = 0.5f) // Gray partial
                    }

                    val isTapped = (selectedIndex == i)
                    drawRect(
                        color = if (isTapped) drawColor.copy(alpha = 0.6f) else drawColor,
                        topLeft = Offset(pixelX, pixelY),
                        size = Size(individualBarWidth, pixelYHeight)
                    )
                }
            }
        }

        // Details Tooltip
        val activeIdx = selectedIndex
        if (activeIdx != null && activeIdx < points.size) {
            val point = points[activeIdx]
            val drawColor = when (point.isHigherThanAvg) {
                true -> Color(0xFFE53935)
                false -> Color(0xFF43A047)
                null -> Color.Gray
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = drawColor.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Fecha: ${DateFormatter.formatDate(point.date)}", style = MaterialTheme.typography.bodySmall)
                        val detailsType = if (point.isFull) "Lleno" else "Parcial"
                        val consLabel = if (point.consumptionVal != null) {
                            "Consumo: ${NumberFormatter.formatDouble2(point.consumptionVal)} L/100km"
                        } else {
                            "Consumo: N/D"
                        }
                        Text(text = "Depósito: $detailsType • $consLabel", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        text = "${point.value}$unitLabel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = drawColor
                    )
                }
            }
        } else {
            Text(
                text = "Presiona sobre una barra para ver detalles.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}

// ------------------- PRICE EVOLUTION LINE & AREA CANVAS -------------------
@Composable
fun PriceChartCanvas(
    points: List<PricePoint>,
    averageValue: Double,
    lineColor: Color,
    unitLabel: String
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val minVal = (points.map { it.value }.minOrNull() ?: 1.0) * 0.95
    val maxVal = (points.map { it.value }.maxOrNull() ?: 2.0) * 1.05
    val delta = if (maxVal - minVal == 0.0) 1.0 else maxVal - minVal

    Column {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            val width = size.width
                            val stepX = width / (points.size - 1).coerceAtLeast(1)
                            var closestIdx = 0
                            var closestDist = Float.MAX_VALUE
                            for (i in points.indices) {
                                val pxX = i * stepX
                                val dist = kotlin.math.abs(pxX - offset.x)
                                if (dist < closestDist) {
                                    closestDist = dist
                                    closestIdx = i
                                }
                            }
                            selectedIndex = closestIdx
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val paddingBottom = 20f
                val paddingTop = 10f
                val drawHeight = canvasHeight - paddingBottom - paddingTop

                val stepX = canvasWidth / (points.size - 1).coerceAtLeast(1)

                // Grid Y helper
                val gridLinesCount = 3
                for (g in 0..gridLinesCount) {
                    val yVal = minVal + (delta * g / gridLinesCount)
                    val pixelY = canvasHeight - paddingBottom - ((yVal - minVal) / delta * drawHeight).toFloat()
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.4f),
                        start = Offset(0f, pixelY),
                        end = Offset(canvasWidth, pixelY),
                        strokeWidth = 1f
                    )
                }

                // Average line (dotted)
                val avgY = canvasHeight - paddingBottom - ((averageValue - minVal) / delta * drawHeight).toFloat()
                drawLine(
                    color = lineColor.copy(alpha = 0.5f),
                    start = Offset(0f, avgY),
                    end = Offset(canvasWidth, avgY),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // Area under the Price Curve (filled)
                val areaPath = Path()
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    if (i == 0) {
                        areaPath.moveTo(pixelX, canvasHeight - paddingBottom)
                        areaPath.lineTo(pixelX, pixelY)
                    } else {
                        areaPath.lineTo(pixelX, pixelY)
                    }
                    if (i == points.size - 1) {
                        areaPath.lineTo(pixelX, canvasHeight - paddingBottom)
                    }
                }
                areaPath.close()

                drawPath(
                    path = areaPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(lineColor.copy(alpha = 0.35f), lineColor.copy(alpha = 0.01f)),
                        startY = paddingTop,
                        endY = canvasHeight - paddingBottom
                    )
                )

                // High Contrast Line path overlay
                val linePath = Path()
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    if (i == 0) {
                        linePath.moveTo(pixelX, pixelY)
                    } else {
                        linePath.lineTo(pixelX, pixelY)
                    }
                }
                drawPath(
                    path = linePath,
                    color = lineColor,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                // Dot overlay
                for (i in points.indices) {
                    val pt = points[i]
                    val pixelX = i * stepX
                    val pixelY = canvasHeight - paddingBottom - ((pt.value - minVal) / delta * drawHeight).toFloat()

                    val isTapped = (selectedIndex == i)
                    drawCircle(
                        color = if (isTapped) Color.White else lineColor,
                        radius = if (isTapped) 7.dp.toPx() else 4.dp.toPx(),
                        center = Offset(pixelX, pixelY)
                    )
                    drawCircle(
                        color = lineColor,
                        radius = if (isTapped) 7.dp.toPx() else 4.dp.toPx(),
                        center = Offset(pixelX, pixelY),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }
        }

        // Price Tooltip Display
        val activeIdx = selectedIndex
        if (activeIdx != null && activeIdx < points.size) {
            val point = points[activeIdx]
            Card(
                colors = CardDefaults.cardColors(containerColor = lineColor.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Fecha: ${DateFormatter.formatDate(point.date)}", style = MaterialTheme.typography.bodySmall)
                        val loc = point.location.ifBlank { "Gasolinera no registrada" }
                        Text(text = "Gasolinera: $loc", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        text = "${NumberFormatter.formatDouble3(point.value)}$unitLabel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = lineColor
                    )
                }
            }
        } else {
            Text(
                text = "Presiona sobre un punto para ver detalles de precio.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}
