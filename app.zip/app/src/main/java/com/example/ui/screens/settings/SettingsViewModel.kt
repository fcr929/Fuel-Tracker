package com.example.ui.screens.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.DependencyProvider
import com.example.data.datastore.AppTheme
import com.example.data.datastore.ThemePreferenceManager
import com.example.data.database.entities.Vehicle
import com.example.data.database.entities.Refuel
import com.example.data.repository.VehicleRepository
import com.example.data.repository.RefuelRepository
import com.example.domain.usecase.ExportCsvUseCase
import com.example.utils.VehicleVisuals
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Locale

enum class ImportStrategy {
    ADD_NO_DUP,
    ADD_ALL,
    REPLACE
}

data class ImportRecord(
    val vehicleName: String,
    val vehicleType: String,
    val fuelType: String,
    val dateStr: String,
    val timeStr: String,
    val odometer: Long,
    val liters: Double,
    val isFull: Boolean,
    val priceTotal: Double,
    val pricePerLiter: Double,
    val location: String,
    val notes: String
)

data class ImportPreview(
    val records: List<ImportRecord>,     // valid parsed records
    val totalRows: Int,                 // all rows
    val errorCount: Int,                // skipped rows due to format error
    val detectedVehicles: List<String>  // unique vehicle names found in CSV
)

class SettingsViewModel(
    private val themePreferenceManager: ThemePreferenceManager = DependencyProvider.themePreferenceManager,
    private val vehicleRepository: VehicleRepository = DependencyProvider.vehicleRepository,
    private val refuelRepository: RefuelRepository = DependencyProvider.refuelRepository,
    private val exportCsvUseCase: ExportCsvUseCase = DependencyProvider.exportCsvUseCase
) : ViewModel() {

    private val dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    val themePreference: StateFlow<AppTheme> = themePreferenceManager.themePreference
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppTheme.SYSTEM)

    val allVehicles: StateFlow<List<Vehicle>> = vehicleRepository.allVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // CSV Import-related State Managers
    val isImporting = MutableStateFlow(false)
    val importErrorMsg = MutableStateFlow<String?>(null)
    val importInfoMsg = MutableStateFlow<String?>(null)
    val importPreviewState = MutableStateFlow<ImportPreview?>(null)
    val importSuccessMessage = MutableStateFlow<String?>(null)

    private var selectedImportUri: Uri? = null

    fun selectTheme(theme: AppTheme) {
        viewModelScope.launch {
            themePreferenceManager.setThemePreference(theme)
        }
    }

    suspend fun saveVehicle(
        id: Int,
        name: String,
        type: String,
        engine: String,
        fuelType: String,
        colorHex: String,
        iconName: String,
        isActive: Boolean
    ): Boolean {
        if (name.isBlank()) return false
        val vehicle = Vehicle(
            id = id,
            name = name.trim(),
            type = type,
            engine = engine.trim(),
            fuelType = fuelType,
            color = colorHex,
            icon = iconName,
            isActive = isActive
        )
        return try {
            if (id == 0) {
                vehicleRepository.insert(vehicle)
            } else {
                vehicleRepository.update(vehicle)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getVehicleById(id: Int): Vehicle? {
        return vehicleRepository.getVehicleById(id)
    }

    suspend fun toggleVehicleActive(vehicle: Vehicle) {
        vehicleRepository.update(vehicle.copy(isActive = !vehicle.isActive))
    }

    suspend fun exportAllHistory(context: Context): Uri? {
        return exportCsvUseCase.executeAll(context)
    }

    suspend fun exportVehicleHistory(context: Context, vehicleId: Int): Uri? {
        return exportCsvUseCase.executeForVehicle(context, vehicleId)
    }

    // CSV Import actions
    fun prepareImport(context: Context, uri: Uri) {
        viewModelScope.launch {
            isImporting.value = true
            importErrorMsg.value = null
            importInfoMsg.value = null
            importPreviewState.value = null
            
            try {
                val preview = parseCsv(context, uri)
                isImporting.value = false
                
                if (preview == null) {
                    importErrorMsg.value = "No se pudo leer el archivo. Asegúrate de tener permisos y de que sea un archivo de texto válido."
                } else if (preview.records.isEmpty()) {
                    if (preview.totalRows == 0) {
                        importInfoMsg.value = "El archivo CSV está vacío."
                    } else {
                        importErrorMsg.value = "El archivo no contiene registros con formato correcto o comprensible."
                    }
                } else {
                    selectedImportUri = uri
                    importPreviewState.value = preview
                }
            } catch (e: Exception) {
                isImporting.value = false
                importErrorMsg.value = "Error al procesar el archivo: ${e.message}"
            }
        }
    }

    fun executeImport(context: Context, strategy: ImportStrategy) {
        val uri = selectedImportUri ?: return
        val preview = importPreviewState.value ?: return
        
        viewModelScope.launch {
            isImporting.value = true
            importPreviewState.value = null // dismiss dialog preview
            
            try {
                val allVehiclesList = vehicleRepository.getAllVehiclesList()
                val vehicleMap = allVehiclesList.associateBy { it.name.lowercase().trim() }.toMutableMap()
                
                // 1. Resolve vehicles: create automatically if not exists
                for (vName in preview.detectedVehicles) {
                    val lowerName = vName.lowercase().trim()
                    if (!vehicleMap.containsKey(lowerName)) {
                        val recordForVehicle = preview.records.firstOrNull { it.vehicleName.lowercase().trim() == lowerName }
                        val type = recordForVehicle?.vehicleType ?: "Coche"
                        val fuelType = recordForVehicle?.fuelType ?: "Gasolina 95"
                        
                        // Select random color
                        val randomColorNum = (Math.random() * VehicleVisuals.presetColors.size).toInt()
                        val colorHex = VehicleVisuals.presetColors[randomColorNum].first
                        
                        val iconKey = when (type.lowercase()) {
                            "moto", "motocicleta" -> "ic_motorcycle"
                            "furgoneta", "van" -> "ic_van"
                            "camión", "truck" -> "ic_truck"
                            "quad" -> "ic_quad"
                            else -> "ic_car"
                        }
                        
                        val newVehicle = Vehicle(
                            name = vName.trim(),
                            type = type,
                            engine = "",
                            fuelType = fuelType,
                            color = colorHex,
                            icon = iconKey,
                            isActive = true
                        )
                        val newId = vehicleRepository.insert(newVehicle).toInt()
                        vehicleMap[lowerName] = newVehicle.copy(id = newId)
                    }
                }
                
                // 2. Suppress existing refuels if replacing values (Option C)
                if (strategy == ImportStrategy.REPLACE) {
                    for (vName in preview.detectedVehicles) {
                        val vehicle = vehicleMap[vName.lowercase().trim()]
                        if (vehicle != null) {
                            refuelRepository.deleteForVehicle(vehicle.id)
                        }
                    }
                }
                
                // 3. Load existing refuels for unique duplicates verification (Option A)
                val existingRefuels = if (strategy == ImportStrategy.ADD_NO_DUP) {
                    refuelRepository.allRefuels.first()
                } else {
                    emptyList()
                }
                val existingKeySet = existingRefuels.map { Triple(it.vehicleId, it.date, it.odometer) }.toSet()
                
                // 4. Perform final insertions
                var successCount = 0
                for (rec in preview.records) {
                    val vehicle = vehicleMap[rec.vehicleName.lowercase().trim()] ?: continue
                    val recordDate = parseDate(rec.dateStr, rec.timeStr) ?: System.currentTimeMillis()
                    
                    val isDuplicate = strategy == ImportStrategy.ADD_NO_DUP && 
                        existingKeySet.contains(Triple(vehicle.id, recordDate, rec.odometer))
                    
                    if (!isDuplicate) {
                        val refuel = Refuel(
                            vehicleId = vehicle.id,
                            date = recordDate,
                            liters = rec.liters,
                            isFull = rec.isFull,
                            priceTotal = rec.priceTotal,
                            pricePerLiter = rec.pricePerLiter,
                            odometer = rec.odometer,
                            location = rec.location,
                            notes = rec.notes
                        )
                        refuelRepository.insert(refuel)
                        successCount++
                    }
                }
                
                isImporting.value = false
                importSuccessMessage.value = "$successCount registros importados correctamente. ${preview.errorCount} filas omitidas por error de formato."
                selectedImportUri = null
            } catch (e: Exception) {
                isImporting.value = false
                importErrorMsg.value = "Error al aplicar importación: ${e.message}"
                selectedImportUri = null
            }
        }
    }

    fun dismissSuccessMessage() {
        importSuccessMessage.value = null
    }

    fun dismissError() {
        importErrorMsg.value = null
    }

    fun dismissInfo() {
        importInfoMsg.value = null
    }

    fun dismissPreview() {
        importPreviewState.value = null
        selectedImportUri = null
    }

    // CSV Parse helper logic
    private fun parseCsv(context: Context, uri: Uri): ImportPreview? {
        val records = mutableListOf<ImportRecord>()
        var errorCount = 0
        var totalRows = 0
        val detectedVehicles = mutableSetOf<String>()

        try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val reader = BufferedReader(InputStreamReader(inputStream, "UTF-8"))
            
            val header = reader.readLine() ?: return null
            
            var line = reader.readLine()
            while (line != null) {
                val trimmedLine = line.trim()
                if (trimmedLine.isNotEmpty()) {
                    totalRows++
                    val parsedRow = parseCsvLine(trimmedLine)
                    if (parsedRow.size >= 11) {
                        try {
                            val vehicleName = parsedRow[0].trim()
                            val vehicleType = parsedRow[1].ifEmpty { "Coche" }.trim()
                            val fuelType = parsedRow[2].ifEmpty { "Gasolina 95" }.trim()
                            val dateStr = parsedRow[3].trim()
                            val timeStr = parsedRow[4].trim()
                            
                            val odometer = parsedRow[5].toLongOrNull() ?: throw Exception("Invalid Odometer")
                            val liters = parseDecimal(parsedRow[7]) ?: throw Exception("Invalid Liters")
                            
                            val isFull = parsedRow[8].trim().lowercase() == "sí" || parsedRow[8].trim().lowercase() == "si"
                            val priceTotal = parseDecimal(parsedRow[9]) ?: throw Exception("Invalid PriceTotal")
                            val pricePerLiter = parseDecimal(parsedRow[10]) ?: throw Exception("Invalid PricePerLiter")
                            
                            val location = if (parsedRow.size > 12) parsedRow[12].trim() else ""
                            val notes = if (parsedRow.size > 13) parsedRow[13].trim() else ""
                            
                            if (vehicleName.isNotEmpty() && dateStr.isNotEmpty()) {
                                records.add(
                                    ImportRecord(
                                        vehicleName = vehicleName,
                                        vehicleType = vehicleType,
                                        fuelType = fuelType,
                                        dateStr = dateStr,
                                        timeStr = timeStr,
                                        odometer = odometer,
                                        liters = liters,
                                        isFull = isFull,
                                        priceTotal = priceTotal,
                                        pricePerLiter = pricePerLiter,
                                        location = location,
                                        notes = notes
                                    )
                                )
                                detectedVehicles.add(vehicleName)
                            } else {
                                errorCount++
                            }
                        } catch (e: Exception) {
                            errorCount++
                        }
                    } else {
                        errorCount++
                    }
                }
                line = reader.readLine()
            }
            reader.close()
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

        return ImportPreview(
            records = records,
            totalRows = totalRows,
            errorCount = errorCount,
            detectedVehicles = detectedVehicles.toList().sorted()
        )
    }

    private fun parseDecimal(value: String): Double? {
        val clean = value.trim()
            .replace(".", "")
            .replace(",", ".")
        return clean.toDoubleOrNull()
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        var inQuotes = false
        val current = StringBuilder()
        var i = 0
        val cleanLine = if (line.startsWith("\uFEFF")) line.substring(1) else line
        while (i < cleanLine.length) {
            val c = cleanLine[i]
            if (c == '"') {
                if (inQuotes && i + 1 < cleanLine.length && cleanLine[i + 1] == '"') {
                    current.append('"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (c == ';' && !inQuotes) {
                result.add(current.toString())
                current.clear()
            } else {
                current.append(c)
            }
            i++
        }
        result.add(current.toString())
        return result
    }

    private fun parseDate(dateStr: String, timeStr: String): Long? {
        val cleanDate = dateStr.trim()
        val cleanTime = timeStr.trim().ifEmpty { "00:00" }
        return try {
            dateTimeFormat.parse("$cleanDate $cleanTime")?.time
        } catch (e: Exception) {
            null
        }
    }
}
