package com.example.ui.screens.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.DependencyProvider
import com.example.data.datastore.AppTheme
import com.example.data.datastore.ThemePreferenceManager
import com.example.data.database.entities.Vehicle
import com.example.data.repository.VehicleRepository
import com.example.domain.usecase.ExportCsvUseCase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val themePreferenceManager: ThemePreferenceManager = DependencyProvider.themePreferenceManager,
    private val vehicleRepository: VehicleRepository = DependencyProvider.vehicleRepository,
    private val exportCsvUseCase: ExportCsvUseCase = DependencyProvider.exportCsvUseCase
) : ViewModel() {

    val themePreference: StateFlow<AppTheme> = themePreferenceManager.themePreference
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppTheme.SYSTEM)

    val allVehicles: StateFlow<List<Vehicle>> = vehicleRepository.allVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTheme(theme: AppTheme) {
        viewModelScope.launch {
            themePreferenceManager.setThemePreference(theme)
        }
    }

    suspend fun saveVehicle(
        id: Int,
        name: String,
        type: String,
        engine: String,
        fuelType: String,
        colorHex: String,
        iconName: String,
        isActive: Boolean
    ): Boolean {
        if (name.isBlank()) return false
        val vehicle = Vehicle(
            id = id,
            name = name.trim(),
            type = type,
            engine = engine.trim(),
            fuelType = fuelType,
            color = colorHex,
            icon = iconName,
            isActive = isActive
        )
        return try {
            if (id == 0) {
                vehicleRepository.insert(vehicle)
            } else {
                vehicleRepository.update(vehicle)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getVehicleById(id: Int): Vehicle? {
        return vehicleRepository.getVehicleById(id)
    }

    suspend fun toggleVehicleActive(vehicle: Vehicle) {
        vehicleRepository.update(vehicle.copy(isActive = !vehicle.isActive))
    }

    suspend fun exportAllHistory(context: Context): Uri? {
        return exportCsvUseCase.executeAll(context)
    }

    suspend fun exportVehicleHistory(context: Context, vehicleId: Int): Uri? {
        return exportCsvUseCase.executeForVehicle(context, vehicleId)
    }
}
