package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.datastore.AppTheme
import com.example.ui.screens.charts.ChartsScreen
import com.example.ui.screens.history.HistoryScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.refuel.RefuelFormScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.screens.settings.VehicleFormScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Local Service Locator init verification
        val themePrefs = DependencyProvider.themePreferenceManager

        setContent {
            val activePreference by themePrefs.themePreference.collectAsStateWithLifecycle(initialValue = AppTheme.SYSTEM)
            val isDarkTheme = when (activePreference) {
                AppTheme.SYSTEM -> isSystemInDarkTheme()
                AppTheme.LIGHT -> false
                AppTheme.DARK -> true
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                NavigationShell()
            }
        }
    }
}

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Home : Screen("home", "Inicio", Icons.Default.Home)
    object History : Screen("history", "Historial", Icons.Default.History)
    object Charts : Screen("charts", "Gráficas", Icons.Default.BarChart)
    object Settings : Screen("settings", "Ajustes", Icons.Default.Settings)
}

@Composable
fun NavigationShell() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    // Instantiate Shared VM for settings to avoid duplicated db loads
    val settingsViewModel: SettingsViewModel = viewModel()

    val bottomNavItems = listOf(
        Screen.Home,
        Screen.History,
        Screen.Charts,
        Screen.Settings
    )

    val currentRoute = currentDestination?.route
    // Show Bottom Navigation only on core tabs
    val showBottomBar = currentRoute in bottomNavItems.map { it.route }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    bottomNavItems.forEach { screen ->
                        val isSelected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title) },
                            selected = isSelected,
                            modifier = Modifier.testTag("nav_item_${screen.route}"),
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // Tab 1: Dashboard
            composable(Screen.Home.route) {
                HomeScreen(
                    onNavigateToAddRefuel = { vehicleId ->
                        navController.navigate("refuel_form?vehicleId=$vehicleId")
                    },
                    onNavigateToEditRefuel = { refuelId ->
                        navController.navigate("refuel_form?refuelId=$refuelId")
                    },
                    onNavigateToAddVehicle = {
                        navController.navigate("vehicle_form")
                    }
                )
            }

            // Tab 2: Logs History
            composable(Screen.History.route) {
                HistoryScreen(
                    onNavigateToEditRefuel = { refuelId ->
                        navController.navigate("refuel_form?refuelId=$refuelId")
                    }
                )
            }

            // Tab 3: Analytics Graphs
            composable(Screen.Charts.route) {
                ChartsScreen()
            }

            // Tab 4: App Configuration
            composable(Screen.Settings.route) {
                SettingsScreen(
                    onNavigateToAddVehicle = {
                        navController.navigate("vehicle_form")
                    },
                    onNavigateToEditVehicle = { id ->
                        navController.navigate("vehicle_form?vehicleId=$id")
                    },
                    viewModel = settingsViewModel
                )
            }

            // Form screen: Refuel (add / edit)
            composable(
                route = "refuel_form?refuelId={refuelId}&vehicleId={vehicleId}",
                arguments = listOf(
                    navArgument("refuelId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    },
                    navArgument("vehicleId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                )
            ) { backStackEntry ->
                val refuelId = backStackEntry.arguments?.getString("refuelId")?.toIntOrNull()
                val vehicleId = backStackEntry.arguments?.getString("vehicleId")?.toIntOrNull()
                
                RefuelFormScreen(
                    onNavigateBack = { navController.popBackStack() },
                    passedRefuelId = refuelId,
                    passedVehicleId = vehicleId
                )
            }

            // Form screen: Vehicle (add / edit)
            composable(
                route = "vehicle_form?vehicleId={vehicleId}",
                arguments = listOf(
                    navArgument("vehicleId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                )
            ) { backStackEntry ->
                val vehicleId = backStackEntry.arguments?.getString("vehicleId")?.toIntOrNull()
                
                VehicleFormScreen(
                    onNavigateBack = { navController.popBackStack() },
                    vehicleIdToEdit = vehicleId,
                    viewModel = settingsViewModel
                )
            }
        }
    }
}
