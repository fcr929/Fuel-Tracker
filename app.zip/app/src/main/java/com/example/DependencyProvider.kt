package com.example

import android.content.Context
import com.example.data.database.AppDatabase
import com.example.data.datastore.ThemePreferenceManager
import com.example.data.repository.RefuelRepository
import com.example.data.repository.VehicleRepository
import com.example.domain.usecase.CalculateConsumptionUseCase
import com.example.domain.usecase.ExportCsvUseCase
import com.example.domain.usecase.GetStatsUseCase

object DependencyProvider {
    private var isInitialized = false

    lateinit var appDatabase: AppDatabase
        private set
    lateinit var vehicleRepository: VehicleRepository
        private set
    lateinit var refuelRepository: RefuelRepository
        private set
    lateinit var calculateConsumptionUseCase: CalculateConsumptionUseCase
        private set
    lateinit var getStatsUseCase: GetStatsUseCase
        private set
    lateinit var exportCsvUseCase: ExportCsvUseCase
        private set
    lateinit var themePreferenceManager: ThemePreferenceManager
        private set

    fun initialize(context: Context) {
        if (isInitialized) return
        
        val appContext = context.applicationContext
        appDatabase = AppDatabase.getDatabase(appContext)
        vehicleRepository = VehicleRepository(appDatabase.vehicleDao())
        refuelRepository = RefuelRepository(appDatabase.refuelDao())
        
        calculateConsumptionUseCase = CalculateConsumptionUseCase()
        getStatsUseCase = GetStatsUseCase(calculateConsumptionUseCase)
        exportCsvUseCase = ExportCsvUseCase(vehicleRepository, refuelRepository, calculateConsumptionUseCase)
        themePreferenceManager = ThemePreferenceManager(appContext)
        
        isInitialized = true
    }
}
