package com.example.utils

import kotlin.math.roundToLong

object UnitConverter {
    // 1 mi = 1.60934 km
    // 1 gal US = 3.78541 L
    // 1 gal UK = 4.54609 L

    fun kmToMi(km: Double): Double {
        return km / 1.60934
    }

    fun miToKm(mi: Double): Double {
        return mi * 1.60934
    }

    fun lToGalUs(liters: Double): Double {
        return liters / 3.78541
    }

    fun lToGalUk(liters: Double): Double {
        return liters / 4.54609
    }

    fun galUsToL(galUs: Double): Double {
        return galUs * 3.78541
    }

    fun galUkToL(galUk: Double): Double {
        return galUk * 4.54609
    }

    // Convert distance for presentation (e.g., Odometer, Traveled)
    fun convertDistance(kmValue: Double, toUnit: String): Double {
        return if (toUnit == "mi") kmToMi(kmValue) else kmValue
    }

    // Convert display distance back to storage (km)
    fun convertDistanceFromUnit(value: Double, fromUnit: String): Double {
        return if (fromUnit == "mi") miToKm(value) else value
    }

    // Convert volume for presentation (e.g., Liters)
    fun convertVolume(lValue: Double, toUnit: String): Double {
        return when (toUnit) {
            "gal_us" -> lToGalUs(lValue)
            "gal_uk" -> lToGalUk(lValue)
            else -> lValue
        }
    }

    // Convert display volume back to storage (L)
    fun convertVolumeFromUnit(value: Double, fromUnit: String): Double {
        return when (fromUnit) {
            "gal_us" -> galUsToL(value)
            "gal_uk" -> galUkToL(value)
            else -> value
        }
    }

    // Convert price per unit for presentation (e.g., €/L to €/gal)
    // Price total is unchanged because currency is converted separately (only dynamic labels, not value conversion).
    // Volume unit changes price per volume unit (e.g. €/L versus €/gal).
    // Price total remains unchanged. So Price per unit = PriceTotal / VolumeUnit.
    // Price per Unit = pricePerLiter * (1 L / 1 VolUnit)
    fun convertPricePerUnit(pricePerLiter: Double, toVolumeUnit: String): Double {
        return when (toVolumeUnit) {
            "gal_us" -> pricePerLiter * 3.78541
            "gal_uk" -> pricePerLiter * 4.54609
            else -> pricePerLiter
        }
    }

    // Convert price per unit back to price per liter
    fun convertPricePerUnitFromUnit(pricePerUnit: Double, fromVolumeUnit: String): Double {
        return when (fromVolumeUnit) {
            "gal_us" -> pricePerUnit / 3.78541
            "gal_uk" -> pricePerUnit / 4.54609
            else -> pricePerUnit
        }
    }

    // Calculate consumption dynamically based on storing km and L
    fun calculateConsumption(kmDiff: Double, liters: Double, distanceUnit: String, volumeUnit: String): Double {
        if (kmDiff <= 0.0 || liters <= 0.0) return 0.0
        val dispDistance = convertDistance(kmDiff, distanceUnit)
        val dispVolume = convertVolume(liters, volumeUnit)
        
        return when {
            distanceUnit == "km" && volumeUnit == "L" -> {
                (dispVolume / dispDistance) * 100.0
            }
            distanceUnit == "mi" && volumeUnit == "gal_us" -> {
                dispDistance / dispVolume
            }
            distanceUnit == "mi" && volumeUnit == "gal_uk" -> {
                dispDistance / dispVolume
            }
            distanceUnit == "km" && volumeUnit == "gal_us" -> {
                dispDistance / dispVolume
            }
            distanceUnit == "km" && volumeUnit == "gal_uk" -> {
                dispDistance / dispVolume
            }
            else -> {
                // Fallback (e.g. mi + L)
                (dispVolume / dispDistance) * 100.0
            }
        }
    }

    // Convert raw L/100km to selection
    fun convertConsumption(l100km: Double, distanceUnit: String, volumeUnit: String): Double {
        if (l100km <= 0.0) return 0.0
        return when {
            distanceUnit == "km" && volumeUnit == "L" -> l100km
            distanceUnit == "mi" && volumeUnit == "gal_us" -> 235.214583 / l100km
            distanceUnit == "mi" && volumeUnit == "gal_uk" -> 282.480936 / l100km
            distanceUnit == "km" && volumeUnit == "gal_us" -> (100.0 / l100km) * 3.78541
            distanceUnit == "km" && volumeUnit == "gal_uk" -> (100.0 / l100km) * 4.54609
            else -> l100km
        }
    }
}
