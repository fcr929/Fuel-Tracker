package com.example.utils

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.HomeRepairService
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Motorcycle
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

object VehicleVisuals {
    fun parseColor(hex: String, fallback: Color = Color.Gray): Color {
        return try {
            Color(android.graphics.Color.parseColor(hex))
        } catch (e: Exception) {
            fallback
        }
    }

    fun getIconVector(iconName: String): ImageVector {
        return when (iconName?.lowercase()) {
            "ic_car", "coche", "coche deportivo" -> Icons.Default.DirectionsCar
            "ic_motorcycle", "moto" -> Icons.Default.Motorcycle
            "ic_van", "furgoneta", "todoterreno" -> Icons.Default.DirectionsBus
            "ic_truck", "camión" -> Icons.Default.LocalShipping
            "ic_quad", "quad" -> Icons.Default.SportsEsports
            else -> Icons.Default.DirectionsCar
        }
    }

    val presetColors = listOf(
        "#4CAF50" to "Verde",
        "#2196F3" to "Azul",
        "#F44336" to "Rojo",
        "#FF9800" to "Naranja",
        "#9C27B0" to "Morado",
        "#00BCD4" to "Cian",
        "#E91E63" to "Rosa",
        "#795548" to "Marrón",
        "#607D8B" to "Gris Azulado",
        "#009688" to "Teal",
        "#FF5722" to "Rojo Coral",
        "#E0E0E0" to "Gris Claro"
    )

    val presetIcons = listOf(
        "ic_car" to "Coche",
        "ic_motorcycle" to "Moto",
        "ic_van" to "Furgoneta",
        "ic_truck" to "Camión",
        "ic_quad" to "Quad"
    )
}
