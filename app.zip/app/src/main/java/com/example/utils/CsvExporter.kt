package com.example.utils

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.database.entities.Refuel
import com.example.data.database.entities.Vehicle
import com.example.domain.usecase.CalculateConsumptionUseCase
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {
    private val dateOnlyFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private val timeOnlyFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val fileDateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())

    fun exportToCsvUri(
        context: Context,
        refuelsAndVehicles: List<Pair<Refuel, Vehicle>>,
        calculateUseCase: CalculateConsumptionUseCase,
        specificVehicleName: String? = null
    ): Uri? {
        val builder = StringBuilder()
        
        // UTF-8 BOM
        builder.append('\uFEFF')
        
        val lang = Locale.getDefault().language.lowercase()
        val headersMap = mapOf(
            "es" to listOf("Vehículo", "Tipo", "Combustible", "Fecha", "Hora", "Km_Odómetro", "Km_Desde_Anterior", "Litros", "Depósito_Lleno", "Precio_Total_EUR", "Precio_por_Litro_EUR", "Consumo_L100km", "Lugar", "Notas"),
            "en" to listOf("Vehicle", "Type", "Fuel_Type", "Date", "Time", "Odometer", "Km_Since_Last", "Liters", "Full_Tank", "Total_Price_EUR", "Price_per_Liter_EUR", "Consumption_L100km", "Location", "Notes"),
            "fr" to listOf("Véhicule", "Type", "Carburant", "Date", "Heure", "Odomètre", "Km_Depuis_Dernier", "Litres", "Plein", "Prix_Total_EUR", "Prix_par_Litre_EUR", "Consommation_L100km", "Lieu", "Notes"),
            "de" to listOf("Fahrzeug", "Typ", "Kraftstoff", "Datum", "Uhrzeit", "Kilometerstand", "Km_Seit_Letztem", "Liter", "Volltank", "Gesamtpreis_EUR", "Preis_pro_Liter_EUR", "Verbrauch_L100km", "Ort", "Notizen"),
            "pt" to listOf("Veículo", "Tipo", "Combustível", "Data", "Hora", "Odômetro", "Km_Desde_Anterior", "Litros", "Tanque_Cheio", "Preço_Total_EUR", "Preço_por_Litro_EUR", "Consumo_L100km", "Local", "Notas"),
            "it" to listOf("Veicolo", "Tipo", "Carburante", "Data", "Ora", "Odometro", "Km_Dall_Ultimo", "Litri", "Pieno", "Prezzo_Totale_EUR", "Prezzo_al_Litro_EUR", "Consumo_L100km", "Luogo", "Note")
        )
        
        val yesNoMap = mapOf(
            "es" to Pair("Sí", "No"),
            "en" to Pair("Yes", "No"),
            "fr" to Pair("Oui", "Non"),
            "de" to Pair("Ja", "Nein"),
            "pt" to Pair("Sim", "Não"),
            "it" to Pair("Sì", "No")
        )

        val headers = headersMap[lang] ?: headersMap["en"]!!
        val (yesVal, noVal) = yesNoMap[lang] ?: yesNoMap["en"]!!
        
        val decimalSeparator = java.text.DecimalFormatSymbols(Locale.getDefault()).decimalSeparator
        val separator = if (decimalSeparator == ',') ";" else ","

        builder.append(headers.joinToString(separator))
        builder.append("\n")

        val groupedByVehicle = refuelsAndVehicles.groupBy { it.first.vehicleId }
        val allExportLines = mutableListOf<ExportRow>()
        
        for ((_, list) in groupedByVehicle) {
            val sortedList = list.sortedBy { it.first.date } // ascending for calculations
            val vehicle = sortedList.first().second
            
            for (i in sortedList.indices) {
                val currentPair = sortedList[i]
                val currentRefuel = currentPair.first
                val prevRefuel = if (i > 0) sortedList[i - 1].first else null
                
                val kmDesdeAnterior = if (prevRefuel != null) {
                    (currentRefuel.odometer - prevRefuel.odometer).toString()
                } else {
                    ""
                }
                
                val consumption = calculateUseCase.execute(currentRefuel, prevRefuel)
                val consumptionStr = if (consumption != null) {
                    NumberFormatter.formatDouble2(consumption)
                } else {
                    ""
                }
                
                allExportLines.add(
                    ExportRow(
                        vehicleName = vehicle.name,
                        vehicleType = vehicle.type,
                        fuelType = vehicle.fuelType,
                        date = currentRefuel.date,
                        odometer = currentRefuel.odometer,
                        kmDesdeAnterior = kmDesdeAnterior,
                        liters = NumberFormatter.formatDouble2(currentRefuel.liters),
                        isFull = if (currentRefuel.isFull) yesVal else noVal,
                        priceTotal = NumberFormatter.formatDouble2(currentRefuel.priceTotal),
                        pricePerLiter = NumberFormatter.formatDouble3(currentRefuel.pricePerLiter),
                        consumption = consumptionStr,
                        location = currentRefuel.location,
                        notes = currentRefuel.notes
                    )
                )
            }
        }
        
        // Sort final rows by date descending
        val sortedExports = allExportLines.sortedByDescending { it.date }
        
        for (row in sortedExports) {
            builder.append(row.toCsvRow(separator))
            builder.append("\n")
        }

        // Write to temporary cache file
        val dateStr = fileDateFormat.format(Date())
        val cleanedVehicleName = specificVehicleName?.replace("[^A-Za-z0-9]".toRegex(), "_")?.lowercase()
        val fileName = if (cleanedVehicleName != null) {
            "fueltracker_${cleanedVehicleName}_$dateStr.csv"
        } else {
            "fueltracker_completo_$dateStr.csv"
        }

        val cacheFile = File(context.cacheDir, fileName)
        try {
            FileOutputStream(cacheFile).use { fos ->
                fos.write(builder.toString().toByteArray(Charsets.UTF_8))
            }
            return FileProvider.getUriForFile(
                context,
                "com.aistudio.fueltracker.pwrvzt.fileprovider",
                cacheFile
            )
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun escapeCsvField(field: String, separator: String): String {
        var clean = field.replace("\"", "\"\"") // escape quotes
        if (clean.contains(separator) || clean.contains("\n") || clean.contains("\"") || clean.contains("\r")) {
            clean = "\"$clean\""
        }
        return clean
    }

    private class ExportRow(
        val vehicleName: String,
        val vehicleType: String,
        val fuelType: String,
        val date: Long,
        val odometer: Long,
        val kmDesdeAnterior: String,
        val liters: String,
        val isFull: String,
        val priceTotal: String,
        val pricePerLiter: String,
        val consumption: String,
        val location: String,
        val notes: String
    ) {
        fun toCsvRow(separator: String): String {
            val dateStr = dateOnlyFormat.format(Date(date))
            val timeStr = timeOnlyFormat.format(Date(date))
            return listOf(
                escapeCsvField(vehicleName, separator),
                escapeCsvField(vehicleType, separator),
                escapeCsvField(fuelType, separator),
                dateStr,
                timeStr,
                odometer.toString(),
                kmDesdeAnterior,
                liters,
                isFull,
                priceTotal,
                pricePerLiter,
                consumption,
                escapeCsvField(location, separator),
                escapeCsvField(notes, separator)
            ).joinToString(separator)
        }
    }
}
