package com.example.utils

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.database.entities.Refuel
import com.example.data.database.entities.Vehicle
import com.example.domain.usecase.CalculateConsumptionUseCase
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {
    private val dateOnlyFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private val timeOnlyFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val fileDateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())

    fun exportToCsvUri(
        context: Context,
        refuelsAndVehicles: List<Pair<Refuel, Vehicle>>,
        calculateUseCase: CalculateConsumptionUseCase,
        specificVehicleName: String? = null
    ): Uri? {
        val builder = StringBuilder()
        
        // UTF-8 BOM
        builder.append('\uFEFF')
        
        // Header
        builder.append("Vehículo;Tipo;Combustible;Fecha;Hora;Km_Odómetro;Km_Desde_Anterior;Litros;Depósito_Lleno;Precio_Total_EUR;Precio_por_Litro_EUR;Consumo_L100km;Lugar;Notas")
        builder.append("\n")

        val groupedByVehicle = refuelsAndVehicles.groupBy { it.first.vehicleId }
        val allExportLines = mutableListOf<ExportRow>()
        
        for ((_, list) in groupedByVehicle) {
            val sortedList = list.sortedBy { it.first.date } // ascending for calculations
            val vehicle = sortedList.first().second
            
            for (i in sortedList.indices) {
                val currentPair = sortedList[i]
                val currentRefuel = currentPair.first
                val prevRefuel = if (i > 0) sortedList[i - 1].first else null
                
                val kmDesdeAnterior = if (prevRefuel != null) {
                    (currentRefuel.odometer - prevRefuel.odometer).toString()
                } else {
                    ""
                }
                
                val consumption = calculateUseCase.execute(currentRefuel, prevRefuel)
                val consumptionStr = if (consumption != null) {
                    NumberFormatter.formatDouble2(consumption)
                } else {
                    ""
                }
                
                allExportLines.add(
                    ExportRow(
                        vehicleName = vehicle.name,
                        vehicleType = vehicle.type,
                        fuelType = vehicle.fuelType,
                        date = currentRefuel.date,
                        odometer = currentRefuel.odometer,
                        kmDesdeAnterior = kmDesdeAnterior,
                        liters = NumberFormatter.formatDouble2(currentRefuel.liters),
                        isFull = if (currentRefuel.isFull) "Sí" else "No",
                        priceTotal = NumberFormatter.formatDouble2(currentRefuel.priceTotal),
                        pricePerLiter = NumberFormatter.formatDouble3(currentRefuel.pricePerLiter),
                        consumption = consumptionStr,
                        location = escapeCsvField(currentRefuel.location),
                        notes = escapeCsvField(currentRefuel.notes)
                    )
                )
            }
        }
        
        // Sort final rows by date descending
        val sortedExports = allExportLines.sortedByDescending { it.date }
        
        for (row in sortedExports) {
            builder.append(row.toCsvRow())
            builder.append("\n")
        }

        // Write to temporary cache file
        val dateStr = fileDateFormat.format(Date())
        val cleanedVehicleName = specificVehicleName?.replace("[^A-Za-z0-9]".toRegex(), "_")?.lowercase()
        val fileName = if (cleanedVehicleName != null) {
            "fueltracker_${cleanedVehicleName}_$dateStr.csv"
        } else {
            "fueltracker_completo_$dateStr.csv"
        }

        val cacheFile = File(context.cacheDir, fileName)
        try {
            FileOutputStream(cacheFile).use { fos ->
                fos.write(builder.toString().toByteArray(Charsets.UTF_8))
            }
            return FileProvider.getUriForFile(
                context,
                "com.aistudio.fueltracker.pwrvzt.fileprovider",
                cacheFile
            )
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun escapeCsvField(field: String): String {
        var clean = field.replace("\"", "\"\"") // escape quotes
        if (clean.contains(";") || clean.contains("\n") || clean.contains("\"") || clean.contains("\r")) {
            clean = "\"$clean\""
        }
        return clean
    }

    private class ExportRow(
        val vehicleName: String,
        val vehicleType: String,
        val fuelType: String,
        val date: Long,
        val odometer: Long,
        val kmDesdeAnterior: String,
        val liters: String,
        val isFull: String,
        val priceTotal: String,
        val pricePerLiter: String,
        val consumption: String,
        val location: String,
        val notes: String
    ) {
        fun toCsvRow(): String {
            val dateStr = dateOnlyFormat.format(Date(date))
            val timeStr = timeOnlyFormat.format(Date(date))
            return "$vehicleName;$vehicleType;$fuelType;$dateStr;$timeStr;$odometer;$kmDesdeAnterior;$liters;$isFull;$priceTotal;$pricePerLiter;$consumption;$location;$notes"
        }
    }
}
