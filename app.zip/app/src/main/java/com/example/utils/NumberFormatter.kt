package com.example.utils

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object NumberFormatter {
    private val localeSymbols: DecimalFormatSymbols
        get() = DecimalFormatSymbols(Locale.getDefault())

    fun formatDouble2(value: Double?): String {
        if (value == null) return ""
        return DecimalFormat("0.00", localeSymbols).format(value)
    }

    fun formatDouble3(value: Double?): String {
        if (value == null) return ""
        return DecimalFormat("0.000", localeSymbols).format(value)
    }

    fun formatPrice(value: Double, symbol: String = "€"): String {
        return "${formatDouble2(value)} $symbol"
    }

    fun formatPricePerLiter(value: Double): String {
        return "${formatDouble3(value)} €/L"
    }

    fun formatPricePerUnit(value: Double, symbol: String = "€", volumeUnit: String = "L"): String {
        return "${formatDouble3(value)} $symbol/$volumeUnit"
    }

    fun formatLiters(value: Double): String {
        return "${formatDouble2(value)} L"
    }

    fun formatVolume(value: Double, volumeUnit: String = "L"): String {
        return "${formatDouble2(value)} $volumeUnit"
    }

    fun formatConsumption(value: Double?): String {
        if (value == null) return "N/D"
        return "${formatDouble2(value)} L/100km"
    }

    fun formatConsumption(value: Double?, consumptionUnit: String, defaultNa: String = "N/D"): String {
        if (value == null) return defaultNa
        return "${formatDouble2(value)} $consumptionUnit"
    }
}
