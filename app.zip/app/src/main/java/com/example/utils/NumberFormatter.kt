package com.example.utils

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object NumberFormatter {
    private val spanishSymbols = DecimalFormatSymbols(Locale("es", "ES")).apply {
        decimalSeparator = ','
        groupingSeparator = '.'
    }

    private val decimal2Format = DecimalFormat("0.00", spanishSymbols)
    private val decimal3Format = DecimalFormat("0.000", spanishSymbols)

    fun formatDouble2(value: Double?): String {
        if (value == null) return ""
        return decimal2Format.format(value)
    }

    fun formatDouble3(value: Double?): String {
        if (value == null) return ""
        return decimal3Format.format(value)
    }

    fun formatPrice(value: Double): String {
        return "${formatDouble2(value)} €"
    }

    fun formatPricePerLiter(value: Double): String {
        return "${formatDouble3(value)} €/L"
    }

    fun formatLiters(value: Double): String {
        return "${formatDouble2(value)} L"
    }

    fun formatConsumption(value: Double?): String {
        if (value == null) return "N/D"
        return "${formatDouble2(value)} L/100km"
    }
}
